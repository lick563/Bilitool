# BiliTool 1.0
Kotlin + Jetpack Compose Material 3 (Expressive)。minSdk 26 (Android 8) / targetSdk 36 (Android 16)。
用 Android Studio（最新稳定版）打开本目录 → Sync → Run。首次同步会自动生成 gradle wrapper jar。
版本规则：小升级 1.0→1.1→…→1.9→2.0；大升级 1.0→1.2→1.4（修改 app/build.gradle.kts 的 versionName / versionCode 与 Screens.kt 的 VERSION_NAME）。
