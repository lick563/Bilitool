@file:OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class, ExperimentalFoundationApi::class)

package com.bilitool.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.LinkAnnotation
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextLinkStyles
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withLink
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val PAGE_SIZE = 20

// ===================== 读评论 =====================
@Composable
fun CommentsScreen(app: AppState, info: VideoInfo, back: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val listState = rememberLazyListState()
    var hot by remember { mutableStateOf(true) }
    var items by remember { mutableStateOf<List<Comment>>(emptyList()) }
    var next by remember { mutableStateOf("") }
    var end by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }
    var page by remember { mutableIntStateOf(0) }
    var ai by remember { mutableStateOf<String?>(null) }
    var aiLoading by remember { mutableStateOf(false) }
    var aiErr by remember { mutableStateOf<String?>(null) }
    var subOf by remember { mutableStateOf<Comment?>(null) }
    var userOf by remember { mutableStateOf<Comment?>(null) }
    var preview by remember { mutableStateOf<Pair<List<String>, Int>?>(null) }
    var menuOf by remember { mutableStateOf<Comment?>(null) }

    suspend fun fetch(reset: Boolean) {
        loading = true; err = null
        try {
            val p = Api.comments(info.aid, hot, if (reset) "" else next)
            items = if (reset) p.items else items + p.items.filter { n -> items.none { it.rpid == n.rpid } }
            next = p.next; end = p.end
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { err = e.message ?: "加载失败" }
        finally { loading = false }
    }
    fun reload() { job?.cancel(); items = emptyList(); next = ""; end = false; page = 0; job = scope.launch { fetch(true) } }
    fun nextPage() {
        if ((page + 1) * PAGE_SIZE < items.size) page++
        else if (!end && !loading) job = scope.launch { val before = items.size; fetch(false); if (items.size > before) page++ }
    }
    fun loadAll() {
        job?.cancel()
        job = scope.launch {
            var guard = 0
            while (!end && guard++ < 1000) { fetch(false); if (err != null) break; delay(250) }
        }
    }
    LaunchedEffect(hot) { reload() }
    LaunchedEffect(page) { listState.scrollToItem(0) }

    fun summarize() {
        val conn = app.aiConn() ?: run { aiErr = "请先到「设置 → AI 设置」添加板块并选择模型"; return }
        aiLoading = true; aiErr = null
        scope.launch {
            try { ai = Ai.chat(conn, Ai.COMMENT_SYSTEM, Ai.commentsPrompt(info, items)) }
            catch (e: CancellationException) { throw e } catch (e: Exception) { aiErr = e.message ?: "总结失败" }
            finally { aiLoading = false }
        }
    }

    val totalPages = maxOf(1, (items.size + PAGE_SIZE - 1) / PAGE_SIZE)
    val shown = items.drop(page * PAGE_SIZE).take(PAGE_SIZE)

    subOf?.let { SubReplyDialog(info.aid, it, onPreview = { l, i -> preview = l to i }) { subOf = null } }
    userOf?.let { UserDialog(it) { userOf = null } }
    preview?.let { ImageViewer(it.first, it.second) { preview = null } }
    menuOf?.let { CommentMenu(it) { menuOf = null } }

    PageScaffold("评论区", back) {
        LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                Row(Modifier.padding(16.dp, 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    FilterChip(hot, { if (!hot) hot = true }, { Text("热门") })
                    FilterChip(!hot, { if (hot) hot = false }, { Text("最新") })
                    Spacer(Modifier.weight(1f))
                    FilledTonalButton({ summarize() }, enabled = items.isNotEmpty() && !aiLoading) {
                        Icon(Icons.Rounded.AutoAwesome, null); Spacer(Modifier.width(6.dp)); Text("AI 总结")
                    }
                }
            }
            if (aiLoading || ai != null || aiErr != null) item {
                Card(Modifier.padding(16.dp, 8.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("AI 评论总结", style = MaterialTheme.typography.titleSmall)
                        if (aiLoading) LoadingBlock("AI 正在阅读评论…")
                        aiErr?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                        ai?.let {
                            SelectionContainer { Text(it, style = MaterialTheme.typography.bodyMedium) }
                            TextButton({ copyText(ctx, it) }) { Text("复制总结") }
                        }
                    }
                }
            }
            items(shown, key = { it.rpid }) { c ->
                CommentRow(c, onUser = { userOf = it }, onReplies = { subOf = it }, onPreview = { l, i -> preview = l to i }, showSubs = true,
                    onMenu = { menuOf = it }, onMention = { id, n -> userOf = stub(id, n) })
            }
            item {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    when {
                        loading -> LoadingBlock("正在加载评论…（已加载 ${items.size} 条）", onCancel = { job?.cancel(); loading = false })
                        err != null -> {
                            Text(err!!, color = MaterialTheme.colorScheme.error)
                            FilledTonalButton({ if (items.isEmpty()) reload() else nextPage() }) { Text("重试") }
                        }
                        items.isEmpty() -> Text("暂无评论（或该视频已关闭评论区）", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    if (items.isNotEmpty()) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            OutlinedButton({ page-- }, enabled = page > 0) { Icon(Icons.Rounded.ChevronLeft, null); Text("上一页") }
                            Text("第 ${page + 1} / $totalPages${if (!end) "+" else ""} 页", style = MaterialTheme.typography.labelLarge)
                            Button({ nextPage() }, enabled = !loading && ((page + 1) * PAGE_SIZE < items.size || !end)) { Text("下一页"); Icon(Icons.Rounded.ChevronRight, null) }
                        }
                        Text("已加载 ${items.size} 条${if (end) "（全部）" else ""}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        if (!end && !loading) TextButton({ loadAll() }) { Text("加载全部评论") }
                    }
                }
            }
        }
    }
}

/** 统一版式：头像 | 用户行 + 正文 + 图片 + 回复预览 + 底栏（赞/回复/时间） */
@Composable
private fun CommentRow(
    c: Comment, onUser: (Comment) -> Unit, onReplies: (Comment) -> Unit,
    onPreview: (List<String>, Int) -> Unit, showSubs: Boolean,
    onMenu: (Comment) -> Unit = {}, onMention: (Long, String) -> Unit = { _, _ -> },
) {
    val df = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }
    Column {
        Row(Modifier.fillMaxWidth().combinedClickable(onClick = {}, onLongClick = { onMenu(c) }).padding(horizontal = 16.dp, vertical = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Avatar(c.avatar, 40.dp, Modifier.clickable { onUser(c) })
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(c.user, style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, maxLines = 1,
                        modifier = Modifier.weight(1f, fill = false).clickable { onUser(c) })
                    if (c.level > 0) Tag("Lv${c.level}", MaterialTheme.colorScheme.secondaryContainer)
                    if (c.top) Tag("置顶", MaterialTheme.colorScheme.tertiaryContainer)
                    Spacer(Modifier.weight(1f))
                    IconButton({ onUser(c) }, Modifier.size(32.dp)) { Icon(Icons.Rounded.PersonSearch, "查询用户", Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
                ExpandableText(c.text, c.members, onMention)
                if (c.pics.isNotEmpty()) FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    c.pics.take(9).forEachIndexed { i, u ->
                        RemoteImage(u, Modifier.size(88.dp).clip(RoundedCornerShape(10.dp)).clickable { onPreview(c.pics, i) }, ContentScale.Crop, maxW = 400)
                    }
                }
                if (showSubs) c.subs.take(3).forEach { s ->
                    Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.surfaceContainer) {
                        Text("${s.user}：${s.text}", Modifier.padding(10.dp).fillMaxWidth(), style = MaterialTheme.typography.bodySmall, maxLines = 3)
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Rounded.ThumbUp, "点赞", Modifier.size(16.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(c.like.fmtCount(), style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Row(Modifier.clickable(enabled = showSubs && c.replyCount > 0) { onReplies(c) }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Icon(Icons.Rounded.ChatBubbleOutline, "回复", Modifier.size(16.dp), tint = if (showSubs && c.replyCount > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(if (showSubs && c.replyCount > 0) "${c.replyCount} 条回复" else "${c.replyCount}", style = MaterialTheme.typography.labelMedium,
                            color = if (showSubs && c.replyCount > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    Spacer(Modifier.weight(1f))
                    Text(df.format(Date(c.time * 1000)) + if (c.loc.isNotEmpty()) " · ${c.loc.removePrefix("IP属地：")}" else "",
                        style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        HorizontalDivider(Modifier.padding(start = 68.dp), color = MaterialTheme.colorScheme.outlineVariant)
    }
}

@Composable
private fun Tag(text: String, color: androidx.compose.ui.graphics.Color) {
    Surface(shape = RoundedCornerShape(6.dp), color = color) {
        Text(text, Modifier.padding(horizontal = 6.dp, vertical = 1.dp), style = MaterialTheme.typography.labelSmall)
    }
}

private fun stub(mid: Long, name: String) = Comment(0, name, "", 0, 0, 0, "", false, emptyList(), mid = mid)

/** 长评论默认折叠 6 行，可展开；@用户 可点击查询 */
@Composable
private fun ExpandableText(text: String, members: List<Pair<String, Long>>, onMention: (Long, String) -> Unit) {
    var expanded by remember(text) { mutableStateOf(false) }
    var overflow by remember(text) { mutableStateOf(false) }
    val linkColor = MaterialTheme.colorScheme.primary
    val ann = remember(text, members, linkColor) {
        data class Hit(val s: Int, val e: Int, val name: String, val mid: Long)
        val hits = ArrayList<Hit>()
        members.forEach { (n, id) ->
            var from = 0
            while (true) { val k = text.indexOf("@$n", from); if (k < 0) break; hits.add(Hit(k, k + n.length + 1, n, id)); from = k + n.length + 1 }
        }
        val sorted = hits.sortedBy { it.s }
        buildAnnotatedString {
            var pos = 0
            sorted.forEach { h ->
                if (h.s < pos) return@forEach
                append(text.substring(pos, h.s))
                withLink(LinkAnnotation.Clickable("u${h.mid}", TextLinkStyles(SpanStyle(color = linkColor))) { onMention(h.mid, h.name) }) { append("@${h.name}") }
                pos = h.e
            }
            append(text.substring(pos))
        }
    }
    Column {
        Text(ann, style = MaterialTheme.typography.bodyMedium, maxLines = if (expanded) Int.MAX_VALUE else 6,
            onTextLayout = { if (!expanded) overflow = it.hasVisualOverflow })
        if (overflow || expanded) Text(if (expanded) "收起" else "展开全文", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary,
            modifier = Modifier.clickable { expanded = !expanded }.padding(vertical = 4.dp))
    }
}

/** 长按评论的操作菜单：复制 / 选择复制 */
@Composable
private fun CommentMenu(c: Comment, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var select by remember { mutableStateOf(false) }
    if (select) {
        AlertDialog(
            onDismissRequest = onDismiss, title = { Text("选择文字复制") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("长按文字拖动手柄可选取任意一段，再点系统菜单的“复制”。", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    SelectionContainer { Text(c.text, style = MaterialTheme.typography.bodyLarge) }
                }
            },
            confirmButton = { TextButton({ copyText(ctx, c.text); onDismiss() }) { Text("复制全文") } },
            dismissButton = { TextButton(onDismiss) { Text("关闭") } },
        )
        return
    }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("评论操作") },
        text = {
            Column {
                Text("${c.user}：${c.text}", style = MaterialTheme.typography.bodySmall, maxLines = 3, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                val rows = buildList<Triple<String, androidx.compose.ui.graphics.vector.ImageVector, () -> Unit>> {
                    add(Triple("复制评论内容", Icons.Rounded.ContentCopy) { copyText(ctx, c.text); onDismiss() })
                    add(Triple("选择文字复制", Icons.Rounded.TextFields) { select = true })
                    add(Triple("复制「用户名：内容」", Icons.Rounded.ContentCopy) { copyText(ctx, "${c.user}：${c.text}"); onDismiss() })
                    add(Triple("复制用户名", Icons.Rounded.Person) { copyText(ctx, c.user); onDismiss() })
                    if (c.mid != 0L) add(Triple("复制 UID", Icons.Rounded.Badge) { copyText(ctx, c.mid.toString()); onDismiss() })
                }
                rows.forEachIndexed { i, (t, ic, act) ->
                    if (i > 0) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                    ListItem(headlineContent = { Text(t) }, leadingContent = { Icon(ic, null) },
                        colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent), modifier = Modifier.clickable(onClick = act))
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("取消") } },
    )
}

@Composable
private fun UserDialog(c: Comment, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val save = rememberImageSaver()
    var card by remember { mutableStateOf<UserCard?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(c.mid != 0L) }
    var viewer by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(c.mid) {
        if (c.mid == 0L) return@LaunchedEffect
        try { card = Api.userCard(c.mid) } catch (e: CancellationException) { throw e } catch (e: Exception) { err = e.message ?: "查询失败" }
        finally { loading = false }
    }
    val face = card?.face?.ifEmpty { null } ?: c.avatar
    val name = card?.name ?: c.user
    val sign = card?.sign?.ifEmpty { null } ?: c.sign.ifEmpty { null }
    val banner = card?.banner.orEmpty()
    fun summary(): String = buildString {
        append("昵称：$name\nUID：${if (c.mid != 0L) c.mid else "未知"}\n等级：Lv${card?.level ?: c.level}\n")
        card?.sex?.takeIf { it.isNotEmpty() }?.let { append("性别：$it\n") }
        sign?.let { append("签名：$it\n") }
        card?.let { append("粉丝：${it.fans}  关注：${it.following}  投稿：${it.archives}  获赞：${it.likes}\n") }
        card?.official?.takeIf { it.isNotEmpty() }?.let { append("认证：$it\n") }
        card?.vip?.takeIf { it.isNotEmpty() }?.let { append("会员：$it\n") }
        card?.pendant?.takeIf { it.isNotEmpty() }?.let { append("头像框：$it\n") }
        if (c.loc.isNotEmpty()) append("${c.loc}\n")
        if (face.isNotEmpty()) append("头像：$face\n")
        if (banner.isNotEmpty()) append("头图：$banner\n")
        append("主页：https://space.bilibili.com/${c.mid}")
    }
    viewer?.let { ImageViewer(listOf(it), 0) { viewer = null } }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("用户信息") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (banner.isNotEmpty()) RemoteImage(banner, Modifier.fillMaxWidth().aspectRatio(16f / 5f).clip(RoundedCornerShape(12.dp)).clickable { viewer = banner }, ContentScale.Crop, maxW = 1080)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(face, 64.dp, Modifier.clickable(enabled = face.isNotEmpty()) { viewer = face })
                    Column {
                        Text(name, style = MaterialTheme.typography.titleMedium)
                        Text("UID ${if (c.mid != 0L) c.mid else "未知"} · Lv${card?.level ?: c.level}", style = MaterialTheme.typography.bodySmall)
                        Text("点击头像可放大查看", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                if (sign != null) Text(sign, style = MaterialTheme.typography.bodyMedium)
                if (loading) LoadingBlock("正在查询…")
                val info = buildList<Pair<String, String>> {
                    card?.sex?.takeIf { it.isNotEmpty() }?.let { add("性别" to it) }
                    card?.let { add("粉丝 / 关注" to "${it.fans.fmtCount()} / ${it.following.fmtCount()}"); add("投稿 / 获赞" to "${it.archives} / ${it.likes.fmtCount()}") }
                    card?.official?.takeIf { it.isNotEmpty() }?.let { add("认证" to it) }
                    card?.vip?.takeIf { it.isNotEmpty() }?.let { add("会员" to it) }
                    card?.pendant?.takeIf { it.isNotEmpty() }?.let { add("头像框" to it) }
                    if (c.loc.isNotEmpty()) add("IP 属地" to c.loc.removePrefix("IP属地："))
                }
                if (info.isNotEmpty()) SettingsGroup(null, info.map<Pair<String, String>, @Composable () -> Unit> { (k, v) -> { SettingRow(k, v) } })
                err?.let { Text("详细资料获取失败：$it（登录后成功率更高）", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (face.isNotEmpty()) FilledTonalButton({ save(face) }) { Icon(Icons.Rounded.Download, null); Spacer(Modifier.width(4.dp)); Text("保存头像") }
                    if (banner.isNotEmpty()) FilledTonalButton({ save(banner) }) { Icon(Icons.Rounded.Download, null); Spacer(Modifier.width(4.dp)); Text("保存头图") }
                    if (face.isNotEmpty()) OutlinedButton({ copyText(ctx, face) }) { Text("复制头像链接") }
                    OutlinedButton({ copyText(ctx, summary()) }) { Text("复制全部信息") }
                    if (c.mid != 0L) OutlinedButton({ copyText(ctx, c.mid.toString()) }) { Text("复制 UID") }
                }
            }
        },
        confirmButton = { TextButton({ if (c.mid != 0L) openUrl(ctx, "https://space.bilibili.com/${c.mid}") else toast(ctx, "该用户 UID 未知") }) { Text("打开主页") } },
        dismissButton = { TextButton(onDismiss) { Text("关闭") } },
    )
}

@Composable
private fun SubReplyDialog(aid: Long, root: Comment, onPreview: (List<String>, Int) -> Unit, onDismiss: () -> Unit) {
    var pn by remember { mutableIntStateOf(1) }
    var data by remember { mutableStateOf<SubPage?>(null) }
    var loading by remember { mutableStateOf(false) }
    var err by remember { mutableStateOf<String?>(null) }
    var userOf by remember { mutableStateOf<Comment?>(null) }
    var menuOf by remember { mutableStateOf<Comment?>(null) }
    LaunchedEffect(pn) {
        loading = true; err = null
        try { data = Api.subReplies(aid, root.rpid, pn) }
        catch (e: CancellationException) { throw e } catch (e: Exception) { err = e.message ?: "加载失败" }
        finally { loading = false }
    }
    userOf?.let { UserDialog(it) { userOf = null } }
    menuOf?.let { CommentMenu(it) { menuOf = null } }
    val total = data?.total ?: root.replyCount
    val pages = maxOf(1, (total + (data?.pageSize ?: 20) - 1) / (data?.pageSize ?: 20))
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("全部回复（$total）") },
        text = {
            Column {
                LazyColumn(Modifier.heightIn(max = 440.dp)) {
                    item { CommentRow(root, onUser = { userOf = it }, onReplies = {}, onPreview = onPreview, showSubs = false,
                        onMenu = { menuOf = it }, onMention = { id, n -> userOf = stub(id, n) }) }
                    if (loading) item { LoadingBlock("正在加载回复…") }
                    err?.let { e -> item { Text(e, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.error) } }
                    if (!loading) items(data?.list ?: emptyList(), key = { it.rpid }) { s ->
                        CommentRow(s, onUser = { userOf = it }, onReplies = {}, onPreview = onPreview, showSubs = false,
                        onMenu = { menuOf = it }, onMention = { id, n -> userOf = stub(id, n) })
                    }
                }
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    TextButton({ pn-- }, enabled = pn > 1 && !loading) { Text("上一页") }
                    Text("第 $pn / $pages 页", style = MaterialTheme.typography.labelLarge)
                    TextButton({ pn++ }, enabled = pn < pages && !loading) { Text("下一页") }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("关闭") } },
    )
}

// ===================== AI 总结（视频内容） =====================
@Composable
fun SummaryScreen(app: AppState, info: VideoInfo, back: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pageIdx by remember { mutableIntStateOf(info.startPage) }
    var loading by remember { mutableStateOf(true) }
    var res by remember { mutableStateOf<OfficialSummary?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var retry by remember { mutableIntStateOf(0) }
    var own by remember { mutableStateOf<String?>(null) }
    var ownLoading by remember { mutableStateOf(false) }
    var ownErr by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(pageIdx, retry) {
        loading = true; res = null; err = null
        try { res = Api.conclusion(info.bvid, info.pages[pageIdx].cid, info.ownerMid) }
        catch (e: CancellationException) { throw e } catch (e: Exception) { err = e.message ?: "获取失败" }
        finally { loading = false }
    }

    fun ownSummary() {
        val conn = app.aiConn() ?: run { ownErr = "请先到「设置 → AI 设置」添加板块并选择模型"; return }
        ownLoading = true; ownErr = null
        scope.launch {
            try {
                val hotList = runCatching { Api.comments(info.aid, true, "").items }.getOrDefault(emptyList())
                val prompt = Ai.commentsPrompt(info, hotList)
                own = Ai.chat(conn,
                    "你是视频内容总结助手。你拿不到视频字幕，只能依据标题、简介和热门评论推测内容。请用简体中文输出：【视频讲了什么】、【观众反馈】、【值得注意】；并在开头注明“以下基于标题、简介与评论推断，未听取视频原声”。不要编造细节。", prompt)
            } catch (e: CancellationException) { throw e } catch (e: Exception) { ownErr = e.message ?: "总结失败" }
            finally { ownLoading = false }
        }
    }

    PageScaffold("AI 总结", back) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(info.title, style = MaterialTheme.typography.titleSmall)
            if (info.pages.size > 1) LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(info.pages.size) { i -> FilterChip(pageIdx == i, { pageIdx = i }, { Text("P${i + 1} ${info.pages[i].part}", maxLines = 1) }) }
            }
            when {
                loading -> LoadingBlock("正在获取 B 站官方 AI 总结…")
                err != null -> {
                    Text(err!!, color = MaterialTheme.colorScheme.error)
                    FilledTonalButton({ retry++ }) { Text("重试") }
                }
                res == null -> Card(colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainer)) {
                    Text("该视频暂无 B 站官方 AI 总结（时长太短、无语音或未生成）。可以用下方自定义 AI 根据简介和热评生成。", Modifier.padding(16.dp))
                }
                else -> {
                    val r = res!!
                    Card(colors = CardDefaults.cardColors(MaterialTheme.colorScheme.primaryContainer)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("内容摘要（B 站官方 AI）", style = MaterialTheme.typography.titleSmall)
                            SelectionContainer { Text(r.summary, style = MaterialTheme.typography.bodyMedium) }
                            TextButton({ copyText(ctx, r.summary) }) { Text("复制摘要") }
                        }
                    }
                    r.outline.forEach { o ->
                        Card(colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainer)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("${fmtTime(o.ts.toFloat())}  ${o.title}", style = MaterialTheme.typography.titleSmall)
                                o.parts.forEach { (t, c) -> Text("${fmtTime(t.toFloat())}  $c", style = MaterialTheme.typography.bodySmall) }
                            }
                        }
                    }
                }
            }
            HorizontalDivider()
            Text("自定义 AI", style = MaterialTheme.typography.titleSmall)
            FilledTonalButton({ ownSummary() }, enabled = !ownLoading) {
                Icon(Icons.Rounded.AutoAwesome, null); Spacer(Modifier.width(6.dp)); Text("根据简介与热评生成总结")
            }
            if (ownLoading) LoadingBlock("AI 正在生成…")
            ownErr?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            own?.let {
                Card(colors = CardDefaults.cardColors(MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.padding(16.dp)) {
                        SelectionContainer { Text(it, style = MaterialTheme.typography.bodyMedium) }
                        TextButton({ copyText(ctx, it) }) { Text("复制") }
                    }
                }
            }
        }
    }
}
