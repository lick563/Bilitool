@file:OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class)

package com.bilitool.app

import android.content.Context
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.PredictiveBackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import com.kyant.backdrop.backdrops.layerBackdrop
import com.kyant.backdrop.backdrops.rememberLayerBackdrop
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*

class AppState(private val store: Store) {
    private fun today() = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())
    var showGuide by mutableStateOf(!store.onboarded)
    var showUpdate by mutableStateOf(store.onboarded && store.seenVersion < VERSION_CODE && store.snoozeDay != today())
    init { if (!store.onboarded) store.seenVersion = VERSION_CODE }
    fun finishGuide() { store.onboarded = true; store.seenVersion = VERSION_CODE; showGuide = false }
    fun replayGuide() { showGuide = true }
    fun dismissUpdate(snoozeToday: Boolean) {
        if (snoozeToday) store.snoozeDay = today() else store.seenVersion = VERSION_CODE
        showUpdate = false
    }
    val aiResults = mutableStateMapOf<String, TestRes>()
    val aiTesting = mutableStateMapOf<String, Boolean>()

    var tab by mutableIntStateOf(0)
    val stack = mutableStateListOf<Route>()
    var input by mutableStateOf("")
    var loading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var info by mutableStateOf<VideoInfo?>(null)
    var themeMode by mutableIntStateOf(store.themeMode)
    var dynamic by mutableStateOf(store.dynamic)
    val aiProfiles = mutableStateListOf<AiProfile>().apply { addAll(store.loadAi()) }
    var aiActiveId by mutableStateOf(store.aiActive)
    var cookie by mutableStateOf(store.cookie)
    var userName by mutableStateOf<String?>(null)
    init { Api.cookie = store.cookie }

    /** 当前选中的 AI（板块 + 地址 + 模型）；所有 AI 功能都使用它 */
    fun aiConn(): AiConn? {
        val p = aiProfiles.firstOrNull { it.id == aiActiveId } ?: return null
        if (p.key.isBlank() || p.selModel.isBlank() || p.selEndpoint.isBlank()) return null
        return AiConn(p.selEndpoint, p.key, p.selModel, "${p.name} · ${p.selModel}")
    }
    fun updateProfile(p: AiProfile) {
        val i = aiProfiles.indexOfFirst { it.id == p.id }
        if (i >= 0) aiProfiles[i] = p else aiProfiles.add(p)
        store.saveAi(aiProfiles)
    }
    fun removeProfile(id: String) {
        aiProfiles.removeAll { it.id == id }; store.saveAi(aiProfiles)
        if (aiActiveId == id) { aiActiveId = ""; store.aiActive = "" }
    }
    fun setActive(id: String) { aiActiveId = id; store.aiActive = id }
    fun saveCookie(c: String) { cookie = c; store.cookie = c; Api.cookie = c }

    val history = mutableStateListOf<HistoryItem>().apply { addAll(store.loadHistory()) }
    private var job: Job? = null
    private var gen = 0

    fun push(r: Route) { stack.add(r) }
    fun pop() { if (stack.isNotEmpty()) stack.removeAt(stack.lastIndex) }
    fun setTheme(m: Int) { themeMode = m; store.themeMode = m }
    fun setDynamicColor(v: Boolean) { dynamic = v; store.dynamic = v }

    fun query(scope: CoroutineScope, text: String = input) {
        job?.cancel(); error = null; loading = true
        val g = ++gen
        job = scope.launch {
            try {
                val i = Api.info(Api.toRef(text))
                info = i
                history.removeAll { it.bvid == i.bvid }
                history.add(0, HistoryItem(i.bvid, i.title, i.cover, i.owner, System.currentTimeMillis()))
                while (history.size > 100) history.removeAt(history.lastIndex)
                store.saveHistory(history)
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { if (g == gen) error = e.message ?: "解析失败" }
            finally { if (g == gen) loading = false }
        }
    }

    fun cancelQuery() { job?.cancel(); gen++; loading = false }

    fun clearHistory() { history.clear(); store.saveHistory(history) }
    fun removeHistory(h: HistoryItem) { history.remove(h); store.saveHistory(history) }

    /** 需要先解析视频的工具入口 */
    fun withInfo(ctx: Context, block: (VideoInfo) -> Unit) {
        val i = info
        if (i == null) { tab = 0; toast(ctx, "请先在首页解析一个视频") } else block(i)
    }
}

@Composable
fun BiliToolApp(store: Store) {
    val ctx = LocalContext.current
    val reduce = remember { Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f }
    val app = remember { AppState(store) }
    LaunchedEffect(app.cookie) { app.userName = if (app.cookie.isBlank()) null else runCatching { Api.myName() }.getOrNull() }
    CompositionLocalProvider(LocalReduceMotion provides reduce) {
        BiliToolTheme(app.dynamic, app.themeMode) {
            Box(Modifier.fillMaxSize()) {
                Root(app)
                if (app.showGuide) OnboardingScreen { app.finishGuide() }
                else if (app.showUpdate) UpdateDialog({ app.dismissUpdate(false) }, { app.dismissUpdate(true) })
            }
        }
    }
}

@Composable
private fun Root(app: AppState) {
    var backProgress by remember { mutableFloatStateOf(0f) }

    // 预测性返回：滑动中实时缩小当前页面，松手提交 / 滑回取消
    PredictiveBackHandler(enabled = app.stack.isNotEmpty()) { flow ->
        try {
            flow.collect { backProgress = it.progress }
            app.pop(); backProgress = 0f
        } catch (e: CancellationException) { backProgress = 0f }
    }
    BackHandler(enabled = app.stack.isEmpty() && app.tab != 0) { app.tab = 0 }

    val sp = spatialSpec<IntOffset>()
    val sf = spatialSpec<Float>()
    val ef = effectsSpec<Float>()

    Box(Modifier.fillMaxSize()) {
        MainScaffold(app)
        AnimatedContent(
            targetState = app.stack.lastOrNull(),
            modifier = Modifier.fillMaxSize(),
            transitionSpec = {
                val pop = initialState != null && !app.stack.contains(initialState)
                val t = if (!pop) {
                    (slideInHorizontally(sp) { it / 4 } + fadeIn(ef)) togetherWith fadeOut(ef)   // Shared axis X
                } else {
                    fadeIn(ef) togetherWith (slideOutHorizontally(sp) { it / 4 } + fadeOut(ef) + scaleOut(sf, targetScale = 0.92f))
                }
                t.apply { targetContentZIndex = if (pop) -1f else 1f }
                    .using(SizeTransform(clip = false) { _, _ -> snap() })
            },
            label = "route",
        ) { route ->
            if (route != null) {
                Surface(Modifier.fillMaxSize().graphicsLayer {
                    val p = backProgress
                    val s = 1f - 0.1f * p
                    scaleX = s; scaleY = s; translationX = size.width * 0.04f * p
                    if (p > 0f) { clip = true; shape = RoundedCornerShape((28f * p).dp) }
                }) { RouteHost(route, app) }
            } else Spacer(Modifier.size(0.dp))
        }
    }
}

@Composable
private fun RouteHost(route: Route, app: AppState) {
    val back = { app.pop() }
    when (route) {
        is Route.Danmaku -> DanmakuScreen(route.info, back)
        is Route.Cover -> CoverScreen(route.info, back)
        is Route.Comments -> CommentsScreen(app, route.info, back)
        is Route.Summary -> SummaryScreen(app, route.info, back)
        is Route.Media -> MediaScreen(app, route.info, route.audio, back)
        Route.Login -> LoginScreen(app, back)
        Route.AiSettings -> AiSettingsScreen(app, back)
        is Route.AiEdit -> AiEditScreen(app, route.id, back)
        Route.Downloads -> DownloadsScreen(back)
        Route.Buzzwords -> BuzzScreen(back)
        Route.Hot -> HotScreen(back)
        Route.ShortLink -> ShortLinkScreen(back)
        Route.About -> AboutScreen(back)
    }
}

private data class TabDef(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector)

@Composable
private fun MainScaffold(app: AppState) {
    val wide = LocalConfiguration.current.screenWidthDp >= 600      // Medium/Expanded 用侧边导航栏
    val tabs = listOf(
        TabDef("首页", Icons.Rounded.Home), TabDef("工具", Icons.Rounded.Construction),
        TabDef("历史", Icons.Rounded.History), TabDef("设置", Icons.Rounded.Settings),
    )
    val ef = effectsSpec<Float>()
    val sf = spatialSpec<Float>()
    val bg = MaterialTheme.colorScheme.background
    // 背景捕获器：内容区（含底色）会被玻璃导航栏实时折射
    val backdrop = key(bg) { rememberLayerBackdrop { drawRect(bg); drawContent() } }
    val barPad = if (wide) 0.dp else GlassBarHeight + 24.dp + WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()

    Box(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxSize()) {
            if (wide) NavigationRail {
                Spacer(Modifier.weight(1f))
                tabs.forEachIndexed { i, t ->
                    NavigationRailItem(app.tab == i, { app.tab = i }, { Icon(t.icon, null) }, label = { Text(t.label) })
                }
                Spacer(Modifier.weight(1f))
            }
            CompositionLocalProvider(LocalBottomBarPadding provides barPad) {
                // Fade through；layerBackdrop 必须加在内容容器上，而不是导航栏上
                AnimatedContent(
                    app.tab, Modifier.weight(1f).layerBackdrop(backdrop),
                    transitionSpec = { (fadeIn(ef) + scaleIn(sf, initialScale = 0.92f)) togetherWith fadeOut(ef) },
                    label = "tabs",
                ) { tab ->
                    when (tab) {
                        0 -> HomeScreen(app); 1 -> ToolsScreen(app); 2 -> HistoryScreen(app); else -> SettingsScreen(app)
                    }
                }
            }
        }
        if (!wide) GlassBottomBar(
            backdrop, tabs.map { it.label }, tabs.map { it.icon }, app.tab, { app.tab = it },
            Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp),
        )
    }
}
