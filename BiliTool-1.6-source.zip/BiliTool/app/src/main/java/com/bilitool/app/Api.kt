package com.bilitool.app

import kotlinx.coroutines.*
import kotlinx.coroutines.sync.withPermit
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.atomic.AtomicLong
import java.util.zip.Inflater
import java.security.MessageDigest
import java.net.URLEncoder
import java.util.TreeMap

object Api {
    /** 登录后的 Cookie（仅发给 bilibili.com 域名） */
    @Volatile var cookie: String = ""
    const val UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
    private const val API = "https://api.bilibili.com"

    private fun conn(url: String, follow: Boolean = true): HttpURLConnection =
        (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000; readTimeout = 30_000; instanceFollowRedirects = follow
            setRequestProperty("User-Agent", UA)
            setRequestProperty("Referer", "https://www.bilibili.com/")
            if (url.contains("bilibili.com")) setRequestProperty("Cookie", if (cookie.isNotEmpty()) (if (cookie.contains("buvid3=")) cookie else "$cookie; buvid3=$BUVID") else "buvid3=$BUVID")
        }
    private val BUVID = java.util.UUID.randomUUID().toString().uppercase() + "infoc"

    suspend fun bytes(url: String): ByteArray = withContext(Dispatchers.IO) {
        val c = conn(url)
        try {
            if (c.responseCode >= 400) error("网络错误 HTTP ${c.responseCode}")
            c.inputStream.use { it.readBytes() }
        } finally { c.disconnect() }
    }

    suspend fun text(url: String): String = String(bytes(url), Charsets.UTF_8)

    /** 手动跟随重定向，用于 b23.tv 短链还原 */
    suspend fun resolve(url: String): String = withContext(Dispatchers.IO) {
        var u = url
        repeat(6) {
            val c = conn(u, follow = false)
            try {
                val code = c.responseCode
                val loc = c.getHeaderField("Location")
                if (code in 300..399 && loc != null) u = URL(URL(u), loc).toString() else return@withContext u
            } finally { c.disconnect() }
        }
        u
    }

    private fun JSONObject.check(): JSONObject {
        if (optInt("code") != 0) error("${optString("message", "请求失败")} (${optInt("code")})")
        return this
    }

    suspend fun toRef(raw: String): Ref {
        var s = raw.trim()
        Regex("""https?://(?:b23\.tv|bili2233\.cn)/\S+""").find(s)?.let { s = resolve(it.value) }
        val p = Regex("""[?&]p=(\d+)""").find(s)?.groupValues?.get(1)?.toIntOrNull() ?: 1
        Regex("""BV[0-9A-Za-z]{10}""").find(s)?.let { return Ref(it.value, null, p) }
        Regex("""(?i)\bav(\d+)""").find(s)?.let { return Ref(null, it.groupValues[1].toLong(), p) }
        error("无法识别：请粘贴视频链接、BV号、av号或 b23.tv 短链")
    }

    suspend fun info(ref: Ref): VideoInfo {
        val q = if (ref.bvid != null) "bvid=${ref.bvid}" else "aid=${ref.aid}"
        val d = JSONObject(text("$API/x/web-interface/view?$q")).check().getJSONObject("data")
        val st = d.optJSONObject("stat")
        val ps = d.getJSONArray("pages")
        val pages = (0 until ps.length()).map {
            val o = ps.getJSONObject(it)
            Page(o.getLong("cid"), o.optInt("page", it + 1), o.optString("part"), o.optInt("duration"))
        }
        return VideoInfo(
            bvid = d.getString("bvid"), aid = d.optLong("aid"), title = d.getString("title"),
            cover = d.getString("pic").replace("http://", "https://"),
            owner = d.optJSONObject("owner")?.optString("name") ?: "", desc = d.optString("desc"),
            view = st?.optLong("view") ?: 0, danmaku = st?.optLong("danmaku") ?: 0,
            like = st?.optLong("like") ?: 0, coin = st?.optLong("coin") ?: 0, favorite = st?.optLong("favorite") ?: 0,
            duration = d.optInt("duration"), pages = pages,
            startPage = (ref.p - 1).coerceIn(0, (pages.size - 1).coerceAtLeast(0)),
            ownerMid = d.optJSONObject("owner")?.optLong("mid") ?: 0,
        )
    }

    // ---------- 弹幕 ----------
    suspend fun danmaku(cid: Long): List<Dm> = withContext(Dispatchers.IO) {
        val raw = bytes("https://comment.bilibili.com/$cid.xml")
        val xml = if (raw.isNotEmpty() && raw[0] == '<'.code.toByte()) String(raw, Charsets.UTF_8) else String(inflate(raw), Charsets.UTF_8)
        val re = Regex("""<d p="([^"]*)">(.*?)</d>""", RegexOption.DOT_MATCHES_ALL)
        re.findAll(xml).mapNotNull { m ->
            val f = m.groupValues[1].split(',')
            if (f.size < 7) return@mapNotNull null
            Dm(
                time = f[0].toFloatOrNull() ?: 0f, mode = f[1].toIntOrNull() ?: 1,
                color = f[3].toLongOrNull()?.toInt() ?: 0xFFFFFF, sendTs = f[4].toLongOrNull() ?: 0,
                hash = f[6], text = unescape(m.groupValues[2]), id = f.getOrNull(7)?.toLongOrNull() ?: 0,
            )
        }.toList()
    }

    private fun inflate(data: ByteArray): ByteArray {
        for (nowrap in listOf(true, false)) {
            try {
                val inf = Inflater(nowrap); inf.setInput(data)
                val out = java.io.ByteArrayOutputStream(); val buf = ByteArray(8192)
                while (!inf.finished()) {
                    val n = inf.inflate(buf)
                    if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break
                    out.write(buf, 0, n)
                }
                inf.end()
                if (out.size() > 0) return out.toByteArray()
            } catch (_: Exception) { }
        }
        error("弹幕数据解码失败")
    }

    fun unescape(s: String) = s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"")
        .replace("&apos;", "'").replace("&#39;", "'").replace("&amp;", "&")

    // ---------- 视频 / 音频直链 ----------
    suspend fun media(bvid: String, cid: Long, audio: Boolean): MediaLink {
        if (!audio) {
            val d = JSONObject(text("$API/x/player/playurl?bvid=$bvid&cid=$cid&qn=64&fnval=1&platform=html5&high_quality=1"))
                .check().getJSONObject("data")
            val du = d.getJSONArray("durl").getJSONObject(0)
            val q = d.optInt("quality")
            val aq = d.optJSONArray("accept_quality"); val ad = d.optJSONArray("accept_description")
            var desc = "MP4（画质代码 $q）"
            if (aq != null && ad != null) for (i in 0 until aq.length()) if (aq.optInt(i) == q) desc = "MP4 · ${ad.optString(i)}"
            return MediaLink(du.getString("url").replace("http://", "https://"), desc, du.optLong("size"), "mp4")
        }
        val d = JSONObject(text("$API/x/player/playurl?bvid=$bvid&cid=$cid&qn=64&fnval=16&fnver=0&fourk=1"))
            .check().getJSONObject("data")
        val arr = d.optJSONObject("dash")?.optJSONArray("audio") ?: error("该视频没有可提取的音频流")
        var best: JSONObject? = null
        for (i in 0 until arr.length()) { val o = arr.getJSONObject(i); if (best == null || o.optInt("bandwidth") > best.optInt("bandwidth")) best = o }
        val b = best ?: error("该视频没有可提取的音频流")
        val url = b.optString("baseUrl").ifEmpty { b.optString("base_url") }
        return MediaLink(url.replace("http://", "https://"), "M4A 音频 · ${b.optInt("bandwidth") / 1000} kbps", 0, "m4a")
    }

    // ---------- WBI 签名（B站新版接口要求，缺少签名时下载地址常会 403） ----------
    private var mixin: String? = null
    private var mixinAt = 0L
    private val MIXIN_TAB = intArrayOf(46,47,18,2,53,8,23,32,15,50,10,31,58,3,45,35,27,43,5,49,33,9,42,19,29,28,14,39,12,38,41,13,37,48,7,16,24,55,40,61,26,17,0,1,60,51,30,4,22,25,54,21,56,59,6,63,57,62,11,36,20,34,44,52)

    private suspend fun mixinKey(): String {
        mixin?.let { if (System.currentTimeMillis() - mixinAt < 3_600_000) return it }
        val w = JSONObject(text("$API/x/web-interface/nav")).getJSONObject("data").getJSONObject("wbi_img")
        val raw = w.getString("img_url").substringAfterLast('/').substringBefore('.') + w.getString("sub_url").substringAfterLast('/').substringBefore('.')
        val k = MIXIN_TAB.map { raw[it] }.joinToString("").take(32)
        mixin = k; mixinAt = System.currentTimeMillis()
        return k
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8").replace("+", "%20")

    suspend fun signed(params: Map<String, String>): String {
        val key = mixinKey()
        val p = TreeMap(params); p["wts"] = (System.currentTimeMillis() / 1000).toString()
        val q = p.entries.joinToString("&") { "${enc(it.key)}=${enc(it.value.filter { c -> c !in "!'()*" })}" }
        val md5 = MessageDigest.getInstance("MD5").digest((q + key).toByteArray()).joinToString("") { "%02x".format(it) }
        return "$q&w_rid=$md5"
    }

    private suspend fun playurl(params: Map<String, String>): JSONObject {
        try {
            return JSONObject(text("$API/x/player/wbi/playurl?${signed(params)}")).check().getJSONObject("data")
        } catch (e: CancellationException) { throw e } catch (_: Exception) { }
        val q = params.entries.joinToString("&") { "${it.key}=${enc(it.value)}" }
        return JSONObject(text("$API/x/player/playurl?$q")).check().getJSONObject("data")
    }

    // ---------- 评论 ----------
    private fun String.https() = when { startsWith("//") -> "https:$this"; startsWith("http://") -> replace("http://", "https://"); else -> this }

    private fun parseComment(o: JSONObject, top: Boolean = false): Comment {
        val subs = o.optJSONArray("replies")?.let { a -> (0 until a.length()).map { parseComment(a.getJSONObject(it)) } } ?: emptyList()
        val mem = o.optJSONObject("member")
        val pics = o.optJSONObject("content")?.optJSONArray("pictures")?.let { a ->
            (0 until a.length()).map { a.getJSONObject(it).optString("img_src").https() }.filter { it.isNotEmpty() }
        } ?: emptyList()
        val members = o.optJSONObject("content")?.optJSONArray("members")?.let { arr ->
            (0 until arr.length()).mapNotNull { i ->
                val mo = arr.getJSONObject(i); val id = mo.optString("mid").toLongOrNull()
                val n = mo.optString("uname"); if (id != null && n.isNotEmpty()) n to id else null
            }
        } ?: emptyList()
        return Comment(
            o.optLong("rpid"), mem?.optString("uname") ?: "", o.optJSONObject("content")?.optString("message") ?: "",
            o.optLong("like"), o.optLong("ctime"), o.optInt("rcount"),
            o.optJSONObject("reply_control")?.optString("location") ?: "", top, subs,
            mid = mem?.optString("mid")?.toLongOrNull() ?: 0, avatar = (mem?.optString("avatar") ?: "").https(),
            level = mem?.optJSONObject("level_info")?.optInt("current_level") ?: 0, sign = mem?.optString("sign") ?: "", pics = pics,
            members = members,
        )
    }

    suspend fun userCard(mid: Long): UserCard {
        val d = JSONObject(text("$API/x/web-interface/card?mid=$mid&photo=true")).check().getJSONObject("data")
        val c = d.getJSONObject("card")
        val vipObj = c.optJSONObject("vip")
        val vip = vipObj?.optJSONObject("label")?.optString("text")?.takeIf { it.isNotEmpty() }
            ?: when (vipObj?.optInt("vipType") ?: 0) { 1 -> "月度大会员"; 2 -> "年度大会员"; else -> "" }
        return UserCard(
            c.optString("name"), c.optString("face").https(), c.optString("sign"), c.optLong("fans"), c.optLong("attention"),
            c.optJSONObject("level_info")?.optInt("current_level") ?: 0, d.optLong("archive_count"), d.optLong("like_num"),
            c.optJSONObject("Official")?.optString("title") ?: "",
            sex = c.optString("sex"), vip = vip, pendant = c.optJSONObject("pendant")?.optString("name") ?: "",
            banner = (d.optJSONObject("space")?.optString("l_img")?.takeIf { it.isNotEmpty() } ?: d.optJSONObject("space")?.optString("s_img") ?: "").https(),
        )
    }

    /** offset 为空=第一页；以 "L:" 开头=旧版接口游标 */
    suspend fun comments(aid: Long, hot: Boolean, offset: String): CPage {
        if (offset.startsWith("L:")) return legacyComments(aid, hot, offset.substring(2).toIntOrNull() ?: 0)
        val p = try { wbiComments(aid, hot, offset) }
        catch (e: CancellationException) { throw e }
        catch (e: Exception) { if (offset.isEmpty()) return legacyComments(aid, hot, 0) else throw e }
        if (offset.isEmpty() && p.items.isEmpty()) return runCatching { legacyComments(aid, hot, 0) }.getOrDefault(p)
        return p
    }

    private suspend fun wbiComments(aid: Long, hot: Boolean, offset: String): CPage {
        val pag = JSONObject().put("offset", offset).toString()
        val q = signed(mapOf("oid" to aid.toString(), "type" to "1", "mode" to (if (hot) "3" else "2"),
            "pagination_str" to pag, "plat" to "1", "web_location" to "1315875"))
        val d = JSONObject(text("$API/x/v2/reply/wbi/main?$q")).check().getJSONObject("data")
        val list = ArrayList<Comment>()
        if (offset.isEmpty()) d.optJSONArray("top_replies")?.let { for (i in 0 until it.length()) list.add(parseComment(it.getJSONObject(i), true)) }
        d.optJSONArray("replies")?.let { for (i in 0 until it.length()) list.add(parseComment(it.getJSONObject(i))) }
        val cur = d.optJSONObject("cursor")
        val next = cur?.optJSONObject("pagination_reply")?.optString("next_offset") ?: ""
        val end = (cur?.optBoolean("is_end") ?: true) || next.isEmpty()
        return CPage(list, next, end)
    }

    private suspend fun legacyComments(aid: Long, hot: Boolean, next: Int): CPage {
        val d = JSONObject(text("$API/x/v2/reply/main?oid=$aid&type=1&mode=${if (hot) 3 else 2}&next=$next&ps=20")).check().getJSONObject("data")
        val list = ArrayList<Comment>()
        if (next == 0) d.optJSONObject("top")?.optJSONObject("upper")?.let { list.add(parseComment(it, true)) }
        d.optJSONArray("replies")?.let { for (i in 0 until it.length()) list.add(parseComment(it.getJSONObject(i))) }
        val cur = d.optJSONObject("cursor")
        val end = cur?.optBoolean("is_end") ?: true
        val nx = cur?.optInt("next") ?: 0
        return CPage(list, if (end) "" else "L:$nx", end || list.isEmpty())
    }

    /** 某条评论的楼中楼回复（按页） */
    suspend fun subReplies(aid: Long, rpid: Long, pn: Int): SubPage {
        val d = JSONObject(text("$API/x/v2/reply/reply?oid=$aid&type=1&root=$rpid&pn=$pn&ps=20")).check().getJSONObject("data")
        val list = d.optJSONArray("replies")?.let { a -> (0 until a.length()).map { parseComment(a.getJSONObject(it)) } } ?: emptyList()
        val pg = d.optJSONObject("page")
        return SubPage(list, pg?.optInt("count") ?: list.size, (pg?.optInt("size") ?: 20).coerceAtLeast(1))
    }

    suspend fun myName(): String? {
        val d = JSONObject(text("$API/x/web-interface/nav")).optJSONObject("data") ?: return null
        return if (d.optBoolean("isLogin")) d.optString("uname") else null
    }

    // ---------- 全量弹幕：按 6 分钟分段拉取（protobuf），再与基础弹幕池合并去重 ----------
    suspend fun danmakuAll(cid: Long, durationSec: Int, onProgress: (done: Int, total: Int, count: Int) -> Unit): DmResult = coroutineScope {
        val segs = maxOf(1, (durationSec + 359) / 360)
        val map = java.util.concurrent.ConcurrentHashMap<String, Dm>()
        fun key(d: Dm) = if (d.id != 0L) "i${d.id}" else "x${d.time}|${d.hash}|${d.text}"
        val done = java.util.concurrent.atomic.AtomicInteger(0)
        val failed = java.util.concurrent.atomic.AtomicInteger(0)
        val sem = kotlinx.coroutines.sync.Semaphore(3)
        (1..segs).map { i ->
            async(Dispatchers.IO) {
                sem.withPermit {
                    var ok = false
                    for (attempt in 1..3) {
                        try {
                            val b = bytes("$API/x/v2/dm/web/seg.so?type=1&oid=$cid&segment_index=$i")
                            if (b.isNotEmpty() && b[0] == '{'.code.toByte()) error("接口返回错误")
                            parseSeg(b).forEach { map[key(it)] = it }
                            ok = true; break
                        } catch (e: CancellationException) { throw e } catch (_: Exception) { delay(500L * attempt) }
                    }
                    if (!ok) failed.incrementAndGet()
                    onProgress(done.incrementAndGet(), segs, map.size)
                }
            }
        }.awaitAll()
        try { danmaku(cid).forEach { map.putIfAbsent(key(it), it) } } catch (e: CancellationException) { throw e } catch (_: Exception) { }
        val f = failed.get()
        val note = when {
            f == 0 -> ""
            f >= segs -> "分段接口不可用，已退回基础弹幕池，数量可能不完整（登录后重试可能恢复）"
            else -> "有 $f/$segs 个分段获取失败（可能被限流），点“重新加载”可补全"
        }
        DmResult(map.values.sortedBy { it.time }, f, segs, note)
    }

    // ---------- B站官方 AI 视频总结 ----------
    suspend fun conclusion(bvid: String, cid: Long, upMid: Long): OfficialSummary? {
        val q = signed(mapOf("bvid" to bvid, "cid" to cid.toString(), "up_mid" to upMid.toString()))
        val d = JSONObject(text("$API/x/web-interface/view/conclusion/get?$q")).check().getJSONObject("data")
        if (d.optInt("code") != 0) return null
        val mr = d.optJSONObject("model_result") ?: return null
        if (mr.optInt("result_type") == 0) return null
        val outline = ArrayList<OutlineItem>()
        mr.optJSONArray("outline")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val parts = o.optJSONArray("part_outline")?.let { p -> (0 until p.length()).map { p.getJSONObject(it).optInt("timestamp") to p.getJSONObject(it).optString("content") } } ?: emptyList()
                outline.add(OutlineItem(o.optString("title"), o.optInt("timestamp"), parts))
            }
        }
        val summary = mr.optString("summary")
        if (summary.isBlank() && outline.isEmpty()) return null
        return OfficialSummary(summary, outline)
    }

    // ---------- DASH 清晰度/帧率/音质列表 ----------
    private fun urlsOf(o: JSONObject): List<String> {
        val l = ArrayList<String>()
        o.optString("baseUrl").ifEmpty { o.optString("base_url") }.takeIf { it.isNotEmpty() }?.let { l.add(it) }
        (o.optJSONArray("backupUrl") ?: o.optJSONArray("backup_url"))?.let { for (i in 0 until it.length()) l.add(it.getString(i)) }
        return l.map { it.replace("http://", "https://") }.distinct()
    }

    private val audioNames = mapOf(30216 to "64K", 30232 to "132K", 30280 to "192K", 30250 to "杜比全景声", 30251 to "Hi-Res 无损")

    suspend fun options(bvid: String, cid: Long): MediaOpts {
        val d = playurl(mapOf("bvid" to bvid, "cid" to cid.toString(), "qn" to "127", "fnval" to "4048", "fnver" to "0", "fourk" to "1"))
        val qn = HashMap<Int, String>()
        val aq = d.optJSONArray("accept_quality"); val ad = d.optJSONArray("accept_description")
        if (aq != null && ad != null) for (i in 0 until minOf(aq.length(), ad.length())) qn[aq.getInt(i)] = ad.getString(i)
        val dash = d.optJSONObject("dash")
        val videos = ArrayList<StreamOpt>()
        dash?.optJSONArray("video")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val codecs = o.optString("codecs")
                if (codecs.startsWith("av01")) continue            // MediaMuxer 不支持 AV1
                val fps = Math.round(o.optString("frameRate").toDoubleOrNull() ?: 0.0).toInt()
                val h = o.optInt("height")
                val name = qn[o.optInt("id")] ?: "${h}P"
                val codec = if (codecs.startsWith("hev") || codecs.startsWith("hvc")) "HEVC" else "AVC"
                videos.add(StreamOpt("$name · ${fps}fps · $codec · ${o.optLong("bandwidth") / 1000}kbps", urlsOf(o), "mp4", h, fps, codecs, o.optLong("bandwidth")))
            }
        }
        videos.sortWith(compareByDescending<StreamOpt> { it.height }.thenByDescending { it.fps }.thenBy { if (it.codecs.startsWith("avc")) 0 else 1 })
        val audios = ArrayList<StreamOpt>()
        fun addAudio(o: JSONObject) {
            val id = o.optInt("id")
            audios.add(StreamOpt("音频 · ${audioNames[id] ?: "${o.optLong("bandwidth") / 1000}kbps"} · ${o.optLong("bandwidth") / 1000}kbps", urlsOf(o), "m4a", bandwidth = o.optLong("bandwidth")))
        }
        dash?.optJSONArray("audio")?.let { for (i in 0 until it.length()) addAudio(it.getJSONObject(i)) }
        dash?.optJSONObject("flac")?.optJSONObject("audio")?.let { addAudio(it) }
        dash?.optJSONObject("dolby")?.optJSONArray("audio")?.let { for (i in 0 until it.length()) addAudio(it.getJSONObject(i)) }
        audios.sortByDescending { it.bandwidth }
        val compat = try {
            val dd = playurl(mapOf("bvid" to bvid, "cid" to cid.toString(), "qn" to "64", "fnval" to "1", "platform" to "html5", "high_quality" to "1"))
            val du = dd.getJSONArray("durl").getJSONObject(0)
            val q = dd.optInt("quality")
            val urls = ArrayList<String>().apply {
                add(du.getString("url"))
                du.optJSONArray("backup_url")?.let { for (i in 0 until it.length()) add(it.getString(i)) }
            }.map { it.replace("http://", "https://") }.distinct()
            StreamOpt("兼容单文件 MP4 · ${qn[q] ?: "画质$q"}（自带声音，无需合并）", urls, "mp4", compat = true, size = du.optLong("size"))
        } catch (_: Exception) { null }
        if (videos.isEmpty() && audios.isEmpty() && compat == null) error("没有可用的媒体流")
        return MediaOpts(videos, audios, compat)
    }

    // ---------- UID -> 昵称（批量，每次 50 个） ----------
    suspend fun userNames(uids: List<Long>): Map<Long, String> {
        val j = JSONObject(text("https://api.vc.bilibili.com/account/v1/user/cards?uids=${uids.joinToString(",")}")).check()
        val arr = j.optJSONArray("data") ?: return emptyMap()
        return (0 until arr.length()).associate { arr.getJSONObject(it).getLong("mid") to arr.getJSONObject(it).optString("name") }
    }

    // ---------- 热搜 / 热词 ----------
    suspend fun hot(): List<String> {
        val arr: JSONArray = JSONObject(text("https://s.search.bilibili.com/main/hotword")).getJSONArray("list")
        return (0 until arr.length()).map { arr.getJSONObject(it).optString("keyword") }.filter { it.isNotBlank() }
    }

    suspend fun buzz(pn: Int): List<Buzz> {
        val html = text("https://bibz.me/buzzword?pn=$pn")
        val re = Regex("""<a[^>]+href="(?:https?://bibz\.me)?/buzzword/(\d+)"[^>]*>(.*?)</a>""", RegexOption.DOT_MATCHES_ALL)
        val seen = LinkedHashMap<String, Buzz>()
        re.findAll(html).forEach { m ->
            val id = m.groupValues[1]
            val parts = m.groupValues[2].replace(Regex("<[^>]+>"), "\u0001").split('\u0001')
                .map { unescape(it.trim()) }.filter { it.isNotEmpty() }.distinct()
            if (parts.isNotEmpty() && id !in seen) seen[id] = Buzz(id, parts[0], parts.getOrNull(1) ?: "")
        }
        return seen.values.toList()
    }
}

/** 弹幕的 midHash 是 UID 十进制字符串的 CRC32。一次扫描 1..45亿，同时反查本视频全部哈希。 */
object Crc {
    private val T = IntArray(256).also {
        for (i in 0..255) { var c = i; repeat(8) { c = if (c and 1 != 0) (c ushr 1) xor -306674912 else c ushr 1 }; it[i] = c }
    }
    private fun step(c: Int, d: Int) = T[(c xor (48 + d)) and 0xff] xor (c ushr 8)

    private class Scan(val bits: LongArray, val hits: HashMap<Int, MutableList<Long>>) {
        fun walk(c: Int, left: Int, v: Long) {
            if (left == 1) {
                for (d in 0..9) {
                    val h = step(c, d).inv(); val k = h and 0xFFFFFF
                    if ((bits[k ushr 6] ushr (k and 63)) and 1L != 0L) {
                        synchronized(hits) { hits[h]?.let { if (it.size < 8) it.add(v * 10 + d) } }
                    }
                }
            } else for (d in 0..9) walk(step(c, d), left - 1, v * 10 + d)
        }
    }

    /** 入参为 8 位小写十六进制哈希；返回 哈希 -> 候选 UID（可能有碰撞） */
    suspend fun reverseAll(hexes: Collection<String>, maxUid: Long = 4_500_000_000L, onProgress: (Float) -> Unit): Map<String, List<Long>> =
        withContext(Dispatchers.Default) {
            val keyToHex = HashMap<Int, String>()
            val hits = HashMap<Int, MutableList<Long>>()
            val bits = LongArray(1 shl 18)
            hexes.forEach { hx ->
                val h = hx.toLongOrNull(16)?.toInt() ?: return@forEach
                keyToHex[h] = hx; hits[h] = ArrayList()
                val k = h and 0xFFFFFF; bits[k ushr 6] = bits[k ushr 6] or (1L shl (k and 63))
            }
            val scan = Scan(bits, hits)
            // 任务 = (位数, 前缀)；后 S 位在任务内枚举
            val tasks = ArrayList<Pair<Int, Long>>()
            for (len in 1..10) {
                val pl = maxOf(1, len - 6); val s = len - pl
                var p = 1L; repeat(pl - 1) { p *= 10 }
                val pe = p * 10; var pow = 1L; repeat(s) { pow *= 10 }
                for (x in p until pe) { if (len == 1 && x == 0L) continue; if (x * pow <= maxUid) tasks.add(len to x) }
            }
            val idx = AtomicLong(0); val total = tasks.size
            val n = Runtime.getRuntime().availableProcessors().coerceIn(2, 8)
            coroutineScope {
                repeat(n) {
                    launch {
                        while (isActive) {
                            val i = idx.getAndIncrement().toInt()
                            if (i >= total) break
                            val (len, prefix) = tasks[i]
                            val pl = prefix.toString().length; val s = len - pl
                            var c = -1; prefix.toString().forEach { ch -> c = step(c, ch - '0') }
                            if (s == 0) { val h = c.inv(); synchronized(hits) { hits[h]?.add(prefix) } } else scan.walk(c, s, prefix)
                            if (i % 200 == 0) onProgress(i.toFloat() / total)
                        }
                    }
                }
            }
            onProgress(1f)
            hits.entries.associate { (k, v) -> keyToHex[k]!! to v.sorted() }
        }
}


// ---------- 最小 protobuf 解析（DmSegMobileReply / DanmakuElem） ----------
private class Pb(val b: ByteArray, var p: Int, val end: Int) {
    fun more() = p < end
    fun varint(): Long {
        var r = 0L; var s = 0
        while (true) { val x = b[p++].toInt(); r = r or ((x and 0x7f).toLong() shl s); if (x and 0x80 == 0) break; s += 7 }
        return r
    }
    fun skip(wire: Int) { when (wire) { 0 -> varint(); 1 -> p += 8; 2 -> { val l = varint().toInt(); p += l }; 5 -> p += 4; else -> error("bad wire") } }
    fun str(): String { val l = varint().toInt(); val s = String(b, p, l, Charsets.UTF_8); p += l; return s }
}

private fun parseSeg(b: ByteArray): List<Dm> {
    val out = ArrayList<Dm>(); val r = Pb(b, 0, b.size)
    while (r.more()) {
        val tag = r.varint().toInt(); val f = tag ushr 3; val w = tag and 7
        if (f == 1 && w == 2) { val l = r.varint().toInt(); val e = Pb(b, r.p, r.p + l); r.p += l; out.add(parseElem(e)) } else r.skip(w)
    }
    return out
}

private fun parseElem(e: Pb): Dm {
    var id = 0L; var prog = 0L; var mode = 1; var color = 0xFFFFFF; var ctime = 0L; var hash = ""; var text = ""
    while (e.more()) {
        val tag = e.varint().toInt(); val f = tag ushr 3; val w = tag and 7
        when {
            f == 1 && w == 0 -> id = e.varint()
            f == 2 && w == 0 -> prog = e.varint()
            f == 3 && w == 0 -> mode = e.varint().toInt()
            f == 5 && w == 0 -> color = e.varint().toInt()
            f == 8 && w == 0 -> ctime = e.varint()
            f == 6 && w == 2 -> hash = e.str()
            f == 7 && w == 2 -> text = e.str()
            else -> e.skip(w)
        }
    }
    return Dm(prog / 1000f, mode, color, ctime, hash, text, id)
}
