package com.bilitool.app

import java.util.Locale

data class Page(val cid: Long, val page: Int, val part: String, val duration: Int)

data class VideoInfo(
    val bvid: String, val aid: Long, val title: String, val cover: String,
    val owner: String, val desc: String,
    val view: Long, val danmaku: Long, val like: Long, val coin: Long, val favorite: Long,
    val duration: Int, val pages: List<Page>, val startPage: Int = 0, val ownerMid: Long = 0,
)

data class Dm(val time: Float, val mode: Int, val color: Int, val sendTs: Long, val hash: String, val text: String, val id: Long = 0)
data class MediaLink(val url: String, val desc: String, val size: Long, val ext: String)
data class HistoryItem(val bvid: String, val title: String, val cover: String, val owner: String, val ts: Long)
data class Buzz(val id: String, val title: String, val pinyin: String)
data class Ref(val bvid: String?, val aid: Long?, val p: Int)

sealed interface Route {
    data class Danmaku(val info: VideoInfo) : Route
    data class Cover(val info: VideoInfo) : Route
    data class Media(val info: VideoInfo, val audio: Boolean) : Route
    data class Comments(val info: VideoInfo) : Route
    data class Summary(val info: VideoInfo) : Route
    data class AiEdit(val id: String) : Route
    data object Login : Route
    data object AiSettings : Route
    data object Downloads : Route
    data object Buzzwords : Route
    data object Hot : Route
    data object ShortLink : Route
    data object About : Route
}

fun Long.fmtCount(): String = if (this >= 10_000) String.format(Locale.US, "%.1f万", this / 10000.0) else toString()

fun fmtTime(sec: Float): String {
    val s = sec.toInt()
    return String.format(Locale.US, "%02d:%02d", s / 60, s % 60)
}

fun fmtSize(b: Long): String = when {
    b <= 0 -> "未知大小"
    b >= 1 shl 20 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
    else -> String.format(Locale.US, "%.0f KB", b / 1024.0)
}

data class StreamOpt(
    val label: String, val urls: List<String>, val ext: String,
    val height: Int = 0, val fps: Int = 0, val codecs: String = "", val bandwidth: Long = 0,
    val compat: Boolean = false, val size: Long = 0,
)
data class MediaOpts(val videos: List<StreamOpt>, val audios: List<StreamOpt>, val compat: StreamOpt?)

data class Comment(
    val rpid: Long, val user: String, val text: String, val like: Long, val time: Long,
    val replyCount: Int, val loc: String, val top: Boolean, val subs: List<Comment>,
    val mid: Long = 0, val avatar: String = "", val level: Int = 0, val sign: String = "", val pics: List<String> = emptyList(),
    val members: List<Pair<String, Long>> = emptyList(),
)
data class SubPage(val list: List<Comment>, val total: Int, val pageSize: Int)
data class UserCard(val name: String, val face: String, val sign: String, val fans: Long, val following: Long, val level: Int, val archives: Long, val likes: Long, val official: String,
    val sex: String = "", val vip: String = "", val pendant: String = "", val banner: String = "")
data class CPage(val items: List<Comment>, val next: String, val end: Boolean)
data class OutlineItem(val title: String, val ts: Int, val parts: List<Pair<Int, String>>)
data class OfficialSummary(val summary: String, val outline: List<OutlineItem>)

data class AiModel(val id: String, val endpoint: String)
data class AiProfile(
    val id: String, val name: String, val key: String, val endpoints: List<String>,
    val models: List<AiModel> = emptyList(), val selModel: String = "", val selEndpoint: String = "",
)
data class AiConn(val base: String, val key: String, val model: String, val label: String)
data class DmResult(val list: List<Dm>, val failed: Int, val segments: Int, val note: String)
