@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.bilitool.app

import android.os.Build
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.unit.dp
import com.kyant.backdrop.Backdrop
import com.kyant.backdrop.drawBackdrop
import com.kyant.backdrop.effects.blur
import com.kyant.backdrop.effects.lens
import com.kyant.backdrop.effects.vibrancy
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.roundToInt

/** 底部导航栏占用的高度（含间距），供各页面在列表底部留白 */
val LocalBottomBarPadding = compositionLocalOf { 0.dp }
val GlassBarHeight = 64.dp

/**
 * 液态玻璃底部导航栏（基于 Kyant0/AndroidLiquidGlass 的 backdrop 库）
 * - 整条栏：模糊 + 折射 + 半透明表面
 * - 选中指示器：玻璃胶囊，点击切换 / 左右拖动，按下时放大并增强折射
 */
@Composable
fun GlassBottomBar(
    backdrop: Backdrop,
    labels: List<String>,
    icons: List<ImageVector>,
    selected: Int,
    onSelect: (Int) -> Unit,
    modifier: Modifier = Modifier,
) {
    val n = labels.size
    val cs = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val sdk = Build.VERSION.SDK_INT
    val spec = spatialSpec<Float>()

    val pos = remember { Animatable(selected.toFloat()) }
    var dragging by remember { mutableStateOf(false) }
    LaunchedEffect(selected) { if (!dragging) pos.animateTo(selected.toFloat(), spec) }
    val press by animateFloatAsState(if (dragging) 1f else 0f, spatialSpec(Speed.Fast), label = "press")

    val container = cs.surface.copy(alpha = if (sdk >= 31) 0.45f else 0.92f)
    var barWidthPx by remember { mutableFloatStateOf(0f) }
    val innerPad = with(density) { 4.dp.toPx() }
    val tabW = ((barWidthPx - innerPad * 2) / n).coerceAtLeast(1f)

    Box(
        modifier
            .fillMaxWidth()
            .height(GlassBarHeight)
            .drawBackdrop(
                backdrop = backdrop,
                shape = { CircleShape },
                effects = {
                    // blur 需要 Android 12+，lens/折射 需要 Android 13+（RuntimeShader）；低版本自动降级为半透明表面
                    if (sdk >= 31) { vibrancy(); blur(8f.dp.toPx()) }
                    if (sdk >= 33) lens(24f.dp.toPx(), 24f.dp.toPx())
                },
                onDrawSurface = { drawRect(container) },
            )
            .pointerInput(n, tabW) {
                detectHorizontalDragGestures(
                    onDragStart = { dragging = true },
                    onDragEnd = {
                        dragging = false
                        val t = pos.value.roundToInt().coerceIn(0, n - 1)
                        onSelect(t); scope.launch { pos.animateTo(t.toFloat(), spec) }
                    },
                    onDragCancel = { dragging = false; scope.launch { pos.animateTo(selected.toFloat(), spec) } },
                    onHorizontalDrag = { change, dx ->
                        change.consume()
                        scope.launch { pos.snapTo((pos.value + dx / tabW).coerceIn(0f, (n - 1).toFloat())) }
                    },
                )
            }
            .onSizeChanged { barWidthPx = it.width.toFloat() }
            .padding(horizontal = 4.dp),
    ) {
        // 选中指示器（玻璃胶囊）
        Box(
            Modifier
                .align(Alignment.CenterStart)
                .graphicsLayer { translationX = pos.value * tabW }
                .drawBackdrop(
                    backdrop = backdrop,
                    shape = { CircleShape },
                    effects = { if (sdk >= 33) lens(10f.dp.toPx() * press, 14f.dp.toPx() * press) },
                    layerBlock = { val s = 1f + 0.18f * press; scaleX = s; scaleY = s },
                    onDrawSurface = { drawRect(cs.primary.copy(alpha = 0.16f - 0.06f * press)) },
                )
                .height(56.dp)
                .width(with(density) { tabW.toDp() }),
        )

        // 标签
        Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
            for (i in 0 until n) {
                val t = 1f - abs(pos.value - i).coerceIn(0f, 1f)
                val color: Color = lerp(cs.onSurfaceVariant, cs.primary, t)
                Column(
                    Modifier
                        .weight(1f).fillMaxHeight()
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, role = Role.Tab) { onSelect(i) },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                ) {
                    Icon(icons[i], contentDescription = null, tint = color, modifier = Modifier.size(24.dp))
                    Text(labels[i], style = MaterialTheme.typography.labelMedium, color = color)
                }
            }
        }
    }
}
