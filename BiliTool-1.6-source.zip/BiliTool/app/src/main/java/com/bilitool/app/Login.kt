@file:OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class)

package com.bilitool.app

import android.annotation.SuppressLint
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import kotlinx.coroutines.launch

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun LoginScreen(app: AppState, back: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var manual by remember { mutableStateOf("") }
    var showManual by remember { mutableStateOf(false) }
    var checking by remember { mutableStateOf(false) }
    val loggedIn = app.cookie.contains("SESSDATA=")

    fun capture(c: String?) {
        if (c.isNullOrBlank() || !c.contains("SESSDATA=") || checking) return
        checking = true
        scope.launch {
            app.saveCookie(c)
            val name = runCatching { Api.myName() }.getOrNull()
            app.userName = name
            checking = false
            if (name != null) { toast(ctx, "登录成功：$name"); back() } else toast(ctx, "Cookie 已保存，但未能验证登录状态")
        }
    }

    PageScaffold("账号登录", back, actions = {
        if (loggedIn) TextButton({
            app.saveCookie(""); app.userName = null
            CookieManager.getInstance().removeAllCookies(null); CookieManager.getInstance().flush()
            toast(ctx, "已退出登录")
        }) { Text("退出") }
        TextButton({ showManual = !showManual }) { Text("手动粘贴") }
    }) {
        Column(Modifier.fillMaxSize()) {
            Text(
                if (loggedIn) "当前已登录：${app.userName ?: "（正在验证）"}。重新登录会覆盖现有 Cookie。"
                else "在下方页面登录 B 站账号（扫码 / 密码 / 短信均可），登录成功后会自动保存 Cookie。登录后可解锁更高画质，并提高弹幕、评论接口的成功率。",
                Modifier.padding(16.dp, 8.dp), style = MaterialTheme.typography.bodySmall,
            )
            Text("Cookie 等同于账号凭证，只保存在本机、只发送给 bilibili.com，请勿分享给他人。",
                Modifier.padding(16.dp, 0.dp), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
            if (showManual) Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(manual, { manual = it }, Modifier.fillMaxWidth(), label = { Text("粘贴完整 Cookie（需包含 SESSDATA）") },
                    visualTransformation = PasswordVisualTransformation(), maxLines = 3)
                Button({ capture(manual.trim()) }, enabled = manual.contains("SESSDATA=")) { Text("保存并验证") }
            }
            if (checking) LoadingBlock("正在验证登录状态…")
            AndroidView(
                modifier = Modifier.fillMaxWidth().weight(1f),
                factory = { c ->
                    WebView(c).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        CookieManager.getInstance().setAcceptCookie(true)
                        CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                        webViewClient = object : WebViewClient() {
                            override fun onPageFinished(view: WebView?, url: String?) {
                                capture(CookieManager.getInstance().getCookie("https://www.bilibili.com"))
                            }
                        }
                        loadUrl("https://passport.bilibili.com/login")
                    }
                },
                onRelease = { it.destroy() },
            )
            Button({ capture(CookieManager.getInstance().getCookie("https://www.bilibili.com")) }, Modifier.fillMaxWidth().padding(16.dp)) {
                Text("我已登录，获取 Cookie")
            }
        }
    }
}
