@file:OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class)

package com.bilitool.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import java.util.UUID

data class TestRes(val ok: Boolean, val ms: Long, val models: List<String>, val msg: String)

private val PRESETS = listOf(
    "OpenAI" to "https://api.openai.com/v1",
    "DeepSeek" to "https://api.deepseek.com",
    "硅基流动" to "https://api.siliconflow.cn/v1",
    "OpenRouter" to "https://openrouter.ai/api/v1",
    "Moonshot" to "https://api.moonshot.cn/v1",
    "智谱" to "https://open.bigmodel.cn/api/paas/v4",
    "阿里百炼" to "https://dashscope.aliyuncs.com/compatible-mode/v1",
)

private fun host(u: String) = u.removePrefix("https://").removePrefix("http://").substringBefore('/')

/** 测试一个板块下所有已选地址，并把获取到的模型合并进板块 */
suspend fun testAiProfile(ctx: android.content.Context, app: AppState, id: String) {
    val p = app.aiProfiles.firstOrNull { it.id == id } ?: return
    if (p.endpoints.isEmpty()) { toast(ctx, "「${p.name}」还没有选择 API 地址"); return }
    if (p.key.isBlank()) { toast(ctx, "「${p.name}」还没有填写 API Key"); return }
    app.aiTesting[id] = true
    try {
        val res = coroutineScope {
            p.endpoints.map { ep ->
                async {
                    val t0 = System.currentTimeMillis()
                    val r = try { TestRes(true, System.currentTimeMillis() - t0, Ai.listModels(ep, p.key), "") }
                    catch (e: CancellationException) { throw e }
                    catch (e: Exception) { TestRes(false, System.currentTimeMillis() - t0, emptyList(), e.message ?: "失败") }
                    app.aiResults["$id|$ep"] = r; ep to r
                }
            }.awaitAll()
        }
        val cur = app.aiProfiles.firstOrNull { it.id == id } ?: return
        val okEps = res.filter { it.second.ok }.map { it.first }
        val fresh = res.filter { it.second.ok }.flatMap { (ep, r) -> r.models.map { AiModel(it, ep) } }
        val others = cur.models.filter { it.endpoint !in okEps }
        app.updateProfile(cur.copy(models = (others + fresh).distinct()))
    } finally { app.aiTesting[id] = false }
}

// ===================== AI 板块列表 =====================
@Composable
fun AiSettingsScreen(app: AppState, back: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var adding by remember { mutableStateOf(false) }
    var testingAll by remember { mutableStateOf(false) }

    PageScaffold("AI 设置", back, actions = {
        TextButton({ adding = true }) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(4.dp)); Text("添加") }
    }) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            SettingsGroup("当前使用", listOf {
                SettingRow(app.aiConn()?.label ?: "尚未选择模型", "评论总结、视频总结都会使用这里选中的模型", Icons.Rounded.AutoAwesome)
            })
            SettingsGroup("工具", listOf {
                SettingRow(
                    "一键测试全部板块", if (testingAll) "测试中…" else "测试每个板块的所有 API 地址并获取模型列表", Icons.Rounded.NetworkCheck,
                    trailing = { if (testingAll) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) },
                    onClick = {
                        if (!testingAll) scope.launch {
                            testingAll = true
                            try { coroutineScope { app.aiProfiles.map { launch { testAiProfile(ctx, app, it.id) } }.joinAll() } } finally { testingAll = false }
                        }
                    },
                )
            })
            val rows: List<@Composable () -> Unit> = if (app.aiProfiles.isEmpty()) listOf {
                SettingRow("还没有板块", "点右上角「添加」选择提供商", Icons.Rounded.Add)
            } else app.aiProfiles.map<AiProfile, @Composable () -> Unit> { p ->
                {
                    val eps = p.endpoints.joinToString("、") { host(it) }.ifEmpty { "未选择地址" }
                    SettingRow(
                        p.name.ifBlank { "未命名" }, "$eps · ${p.selModel.ifEmpty { "未选模型" }}", Icons.Rounded.SmartToy,
                        trailing = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (app.aiTesting[p.id] == true) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                else if (app.aiActiveId == p.id) Text("使用中", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
                                Chevron()
                            }
                        },
                        onClick = { app.push(Route.AiEdit(p.id)) },
                    )
                }
            }
            SettingsGroup("AI 板块（点击编辑）", rows)
        }
    }
    if (adding) AddAiDialog({ adding = false }) { picked, custom ->
        adding = false
        val created = ArrayList<AiProfile>()
        picked.forEach { (n, u) -> created.add(AiProfile(UUID.randomUUID().toString(), n, "", listOf(u))) }
        if (custom) created.add(AiProfile(UUID.randomUUID().toString(), "自定义 AI", "", emptyList()))
        created.forEach { app.updateProfile(it) }
        if (created.size == 1) app.push(Route.AiEdit(created[0].id))
        else if (created.isNotEmpty()) toast(ctx, "已添加 ${created.size} 个板块，点击板块填写 API Key")
    }
}

@Composable
private fun AddAiDialog(onDismiss: () -> Unit, onAdd: (List<Pair<String, String>>, Boolean) -> Unit) {
    val ctx = LocalContext.current
    val checked = remember { mutableStateListOf<Int>() }
    var custom by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("添加 AI") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("选择提供商（可多选），添加后点击板块填写 API Key", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(8.dp))
                PRESETS.forEachIndexed { i, (n, u) ->
                    Row(Modifier.fillMaxWidth().clickable { if (i in checked) checked.remove(i) else checked.add(i) }, verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(i in checked, { if (it) checked.add(i) else checked.remove(i) })
                        Column { Text(n); Text(host(u), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    }
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
                }
                Row(Modifier.fillMaxWidth().clickable { custom = !custom }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(custom, { custom = it })
                    Column { Text("自定义"); Text("空白板块，自行填写地址", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            }
        },
        confirmButton = {
            TextButton({
                if (checked.isEmpty() && !custom) toast(ctx, "请先选择要添加的 AI") else onAdd(checked.sorted().map { PRESETS[it] }, custom)
            }) { Text("添加") }
        },
        dismissButton = { TextButton(onDismiss) { Text("取消") } },
    )
}

// ===================== 板块编辑 =====================
@Composable
private fun EditTextDialog(title: String, init: String, secret: Boolean, hint: String? = null, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var v by remember { mutableStateOf(init) }
    var show by remember { mutableStateOf(!secret) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text(title) },
        text = {
            OutlinedTextField(v, { v = it }, Modifier.fillMaxWidth(), singleLine = true, placeholder = hint?.let { { Text(it) } },
                visualTransformation = if (show) VisualTransformation.None else PasswordVisualTransformation(),
                trailingIcon = if (secret) { { IconButton({ show = !show }) { Icon(if (show) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, "显示/隐藏") } } } else null)
        },
        confirmButton = { TextButton({ onSave(v.trim()); onDismiss() }) { Text("保存") } },
        dismissButton = { TextButton(onDismiss) { Text("取消") } },
    )
}

@Composable
fun AiEditScreen(app: AppState, id: String, back: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p = app.aiProfiles.firstOrNull { it.id == id }
    if (p == null) { LaunchedEffect(Unit) { back() }; return }
    var dlg by remember { mutableStateOf("") }          // name / key / endpoint / model
    var confirmDel by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }
    var more by remember { mutableStateOf(false) }
    val testing = app.aiTesting[id] == true
    val presetUrls = PRESETS.map { it.second }
    val customs = p.endpoints.filter { it !in presetUrls }
    val active = app.aiActiveId == id

    fun toggle(u: String) = app.updateProfile(p.copy(endpoints = if (u in p.endpoints) p.endpoints - u else p.endpoints + u))
    fun pick(m: AiModel) { app.updateProfile(p.copy(selModel = m.id, selEndpoint = m.endpoint)); app.setActive(id) }

    PageScaffold(p.name.ifBlank { "编辑板块" }, back) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            SettingsGroup("基本信息", listOf(
                { SettingRow("名称", p.name.ifBlank { "未命名" }, Icons.Rounded.Edit, trailing = { Chevron() }, onClick = { dlg = "name" }) },
                { SettingRow("API Key", if (p.key.isBlank()) "未填写" else "••••••••" + p.key.takeLast(4), Icons.Rounded.Key, trailing = { Chevron() }, onClick = { dlg = "key" }) },
            ))
            SettingsGroup("API 地址（可多选）", buildList<@Composable () -> Unit> {
                PRESETS.forEach { (n, u) -> add { SettingRow(n, host(u), trailing = { Checkbox(u in p.endpoints, null) }, onClick = { toggle(u) }) } }
                customs.forEach { u -> add { SettingRow(host(u), u, Icons.Rounded.Link, trailing = { Checkbox(true, null) }, onClick = { toggle(u) }) } }
                add { SettingRow("添加自定义地址", "需以 https:// 开头", Icons.Rounded.Add, onClick = { dlg = "endpoint" }) }
            })
            SettingsGroup("连接测试", buildList<@Composable () -> Unit> {
                add {
                    SettingRow(
                        if (testing) "测试中…" else "测试并获取模型", "检测每个已选地址是否可用，并拉取模型列表", Icons.Rounded.NetworkCheck,
                        trailing = { if (testing) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp) },
                        onClick = { if (!testing) scope.launch { testAiProfile(ctx, app, id) } },
                    )
                }
                p.endpoints.forEach { ep ->
                    app.aiResults["$id|$ep"]?.let { r ->
                        add {
                            SettingRow(
                                host(ep), if (r.ok) "可用 · ${r.ms}ms · ${r.models.size} 个模型" else "失败：${r.msg}",
                                trailing = { Icon(if (r.ok) Icons.Rounded.CheckCircle else Icons.Rounded.Error, null, tint = if (r.ok) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error) },
                            )
                        }
                    }
                }
            })
            val filtered = p.models.filter { search.isBlank() || it.id.contains(search.trim(), true) }
            val shown = if (more) filtered else filtered.take(8)
            SettingsGroup("模型${if (p.models.isNotEmpty()) "（共 ${p.models.size} 个）" else ""}", buildList<@Composable () -> Unit> {
                if (p.models.size > 8) add {
                    OutlinedTextField(search, { search = it }, Modifier.fillMaxWidth().padding(12.dp, 8.dp), singleLine = true,
                        label = { Text("搜索模型") }, leadingIcon = { Icon(Icons.Rounded.Search, null) })
                }
                if (p.models.isEmpty()) add { SettingRow("暂无模型", "先选择地址、填写 Key，再点“测试并获取模型”，或手动添加", Icons.Rounded.SmartToy) }
                shown.forEach { m ->
                    val on = p.selModel == m.id && p.selEndpoint == m.endpoint
                    add {
                        SettingRow(m.id, if (p.endpoints.size > 1) host(m.endpoint) else null,
                            trailing = { if (on) Icon(Icons.Rounded.Check, "已选", tint = MaterialTheme.colorScheme.primary) }, onClick = { pick(m) })
                    }
                }
                if (filtered.size > 8) add { SettingRow(if (more) "收起" else "显示全部 ${filtered.size} 个", null, onClick = { more = !more }) }
                add { SettingRow("手动添加模型", "接口不提供模型列表时使用", Icons.Rounded.Add, onClick = { dlg = "model" }) }
            })
            SettingsGroup("使用", listOf {
                SettingRow(
                    "设为全局使用", if (p.selModel.isBlank()) "请先选择模型" else "当前：${p.selModel}", Icons.Rounded.AutoAwesome,
                    trailing = {
                        Switch(active, { on ->
                            if (!on) app.setActive("") else if (p.selModel.isBlank()) toast(ctx, "请先选择一个模型") else app.setActive(id)
                        })
                    },
                )
            })
            SettingsGroup(null, listOf { SettingRow("删除此板块", "清除其中的 Key 与模型选择", Icons.Rounded.Delete, danger = true, onClick = { confirmDel = true }) })
        }
    }

    when (dlg) {
        "name" -> EditTextDialog("板块名称", p.name, false, onSave = { app.updateProfile(p.copy(name = it)) }) { dlg = "" }
        "key" -> EditTextDialog("API Key", p.key, true, onSave = { app.updateProfile(p.copy(key = it)) }) { dlg = "" }
        "endpoint" -> EditTextDialog("自定义 API 地址", "", false, "https://example.com/v1", onSave = {
            val u = it.trimEnd('/')
            if (!u.startsWith("https://")) toast(ctx, "地址必须以 https:// 开头") else if (u !in p.endpoints) app.updateProfile(p.copy(endpoints = p.endpoints + u))
        }) { dlg = "" }
        "model" -> EditTextDialog("手动添加模型名", "", false, "如 gpt-4o-mini", onSave = {
            val ep = p.endpoints.firstOrNull()
            if (it.isBlank()) return@EditTextDialog
            if (ep == null) toast(ctx, "请先选择 API 地址")
            else { val m = AiModel(it, ep); app.updateProfile(p.copy(models = (p.models + m).distinct(), selModel = m.id, selEndpoint = ep)); app.setActive(id) }
        }) { dlg = "" }
    }
    if (confirmDel) AlertDialog(
        onDismissRequest = { confirmDel = false }, title = { Text("删除板块") }, text = { Text("确定删除「${p.name}」？") },
        confirmButton = { TextButton({ confirmDel = false; app.removeProfile(id); back() }) { Text("删除") } },
        dismissButton = { TextButton({ confirmDel = false }) { Text("取消") } },
    )
}
