package com.bilitool.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

class Store(ctx: Context) {
    private val sp = ctx.getSharedPreferences("bilitool", Context.MODE_PRIVATE)
    var themeMode: Int
        get() = sp.getInt("theme", 0)
        set(v) { sp.edit().putInt("theme", v).apply() }
    var dynamic: Boolean
        get() = sp.getBoolean("dynamic", true)
        set(v) { sp.edit().putBoolean("dynamic", v).apply() }

    var onboarded: Boolean
        get() = sp.getBoolean("onboarded", false)
        set(v) { sp.edit().putBoolean("onboarded", v).apply() }
    var seenVersion: Int
        get() = sp.getInt("seenVersion", 0)
        set(v) { sp.edit().putInt("seenVersion", v).apply() }
    var snoozeDay: String
        get() = sp.getString("snoozeDay", "") ?: ""
        set(v) { sp.edit().putString("snoozeDay", v).apply() }
    var cookie: String
        get() = sp.getString("cookie", "") ?: ""
        set(v) { sp.edit().putString("cookie", v).apply() }
    var aiActive: String
        get() = sp.getString("aiActive", "") ?: ""
        set(v) { sp.edit().putString("aiActive", v).apply() }

    fun loadAi(): List<AiProfile> = try {
        val a = JSONArray(sp.getString("aiProfiles", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            val eps = o.optJSONArray("eps")?.let { x -> (0 until x.length()).map { i -> x.getString(i) } } ?: emptyList()
            val ms = o.optJSONArray("models")?.let { x -> (0 until x.length()).map { i -> AiModel(x.getJSONObject(i).getString("id"), x.getJSONObject(i).getString("e")) } } ?: emptyList()
            AiProfile(o.getString("id"), o.optString("name"), o.optString("key"), eps, ms, o.optString("sm"), o.optString("se"))
        }
    } catch (_: Exception) { emptyList() }

    fun saveAi(list: List<AiProfile>) {
        val a = JSONArray()
        list.forEach { p ->
            a.put(JSONObject().put("id", p.id).put("name", p.name).put("key", p.key)
                .put("eps", JSONArray(p.endpoints))
                .put("models", JSONArray().also { arr -> p.models.forEach { m -> arr.put(JSONObject().put("id", m.id).put("e", m.endpoint)) } })
                .put("sm", p.selModel).put("se", p.selEndpoint))
        }
        sp.edit().putString("aiProfiles", a.toString()).apply()
    }

    fun loadHistory(): List<HistoryItem> = try {
        val a = JSONArray(sp.getString("history", "[]"))
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            HistoryItem(o.getString("b"), o.getString("t"), o.getString("c"), o.optString("o"), o.optLong("ts"))
        }
    } catch (_: Exception) { emptyList() }

    fun saveHistory(list: List<HistoryItem>) {
        val a = JSONArray()
        list.forEach { a.put(JSONObject().put("b", it.bvid).put("t", it.title).put("c", it.cover).put("o", it.owner).put("ts", it.ts)) }
        sp.edit().putString("history", a.toString()).apply()
    }
}
