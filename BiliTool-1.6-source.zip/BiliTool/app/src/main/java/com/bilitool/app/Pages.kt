@file:OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class)

package com.bilitool.app

import android.Manifest
import android.app.DownloadManager
import android.content.pm.PackageManager
import android.os.Build
import android.os.Environment
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun modeName(m: Int) = when (m) { 1, 2, 3 -> "滚动"; 4 -> "底部"; 5 -> "顶部"; 6 -> "逆向"; 7 -> "高级"; 8 -> "代码"; 9 -> "BAS"; else -> "其他" }

// ===================== 封面提取 =====================
@Composable
fun CoverScreen(info: VideoInfo, back: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val ext = info.cover.substringAfterLast('.').substringBefore('?').takeIf { it.length in 3..4 } ?: "jpg"
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/*")) { uri ->
        if (uri != null) scope.launch {
            try { val b = Api.bytes(info.cover); withContext(Dispatchers.IO) { writeUri(ctx, uri, b) }; toast(ctx, "封面已保存") }
            catch (e: Exception) { toast(ctx, "保存失败：${e.message}") }
        }
    }
    PageScaffold("封面提取", back) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(shape = MaterialTheme.shapes.extraLarge) {
                RemoteImage(info.cover, Modifier.fillMaxWidth().aspectRatio(16f / 9f), ContentScale.Fit)
            }
            Text(info.title, style = MaterialTheme.typography.titleMedium)
            Text(info.cover, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button({ saver.launch("${info.bvid}_cover.$ext") }, Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Save, null); Spacer(Modifier.width(8.dp)); Text("保存原图") }
            OutlinedButton({ copyText(ctx, info.cover) }, Modifier.fillMaxWidth()) { Icon(Icons.Rounded.ContentCopy, null); Spacer(Modifier.width(8.dp)); Text("复制图片链接") }
            TextButton({ shareText(ctx, info.cover) }, Modifier.fillMaxWidth()) { Icon(Icons.Rounded.Share, null); Spacer(Modifier.width(8.dp)); Text("分享链接") }
        }
    }
}

// ===================== 热搜 =====================
@Composable
fun HotScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    var list by remember { mutableStateOf<List<String>?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var retry by remember { mutableIntStateOf(0) }
    var q by remember { mutableStateOf("") }
    LaunchedEffect(retry) {
        list = null; err = null
        try { list = Api.hot() } catch (e: CancellationException) { throw e } catch (e: Exception) { err = e.message ?: "加载失败" }
    }
    PageScaffold("B站热搜", back) {
        val l = list
        when {
            err != null -> Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(err!!, color = MaterialTheme.colorScheme.error); FilledTonalButton({ retry++ }) { Text("重试") }
            }
            l == null -> LoadingBlock("正在获取热搜…")
            else -> LazyColumn(Modifier.fillMaxSize()) {
                item {
                    OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(16.dp, 8.dp), singleLine = true, shape = MaterialTheme.shapes.extraLarge,
                        label = { Text("在榜单中筛选，或直接搜索") }, leadingIcon = { Icon(Icons.Rounded.Search, null) },
                        trailingIcon = { if (q.isNotBlank()) IconButton({ openBiliSearch(ctx, q.trim()) }) { Icon(Icons.Rounded.OpenInBrowser, "在B站搜索") } })
                }
                val rows = l.withIndex().filter { q.isBlank() || it.value.contains(q.trim(), true) }
                items(rows.size) { k ->
                    val (i, w) = rows[k]
                    ListItem(modifier = Modifier.clickable { openBiliSearch(ctx, w) },
                        leadingContent = { Text("${i + 1}", style = MaterialTheme.typography.titleMedium,
                            color = if (i < 3) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant) },
                        headlineContent = { Text(w) })
                }
            }
        }
    }
}

// ===================== 短链还原 =====================
@Composable
fun ShortLinkScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var input by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(false) }
    var out by remember { mutableStateOf<String?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    PageScaffold("短链还原", back) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(input, { input = it }, Modifier.fillMaxWidth(), label = { Text("粘贴 b23.tv / bili2233.cn 短链") }, maxLines = 3, shape = MaterialTheme.shapes.large)
            Button({
                loading = true; err = null; out = null
                scope.launch {
                    try {
                        val m = Regex("""https?://(?:b23\.tv|bili2233\.cn)/\S+""").find(input) ?: error("未找到短链")
                        out = Api.resolve(m.value)
                    } catch (e: CancellationException) { throw e } catch (e: Exception) { err = e.message ?: "还原失败" }
                    finally { loading = false }
                }
            }, Modifier.fillMaxWidth(), enabled = input.isNotBlank() && !loading) { Text("还原") }
            if (loading) LoadingBlock("正在还原…")
            err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            out?.let { u ->
                Card(colors = CardDefaults.cardColors(MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(u, style = MaterialTheme.typography.bodyMedium)
                        Regex("""BV[0-9A-Za-z]{10}""").find(u)?.let { Text("BV号：${it.value}", style = MaterialTheme.typography.titleSmall) }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton({ copyText(ctx, u) }) { Text("复制") }
                            OutlinedButton({ openUrl(ctx, u) }) { Text("打开") }
                        }
                    }
                }
            }
        }
    }
}
