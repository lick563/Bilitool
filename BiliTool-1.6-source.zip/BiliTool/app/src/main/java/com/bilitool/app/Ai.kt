package com.bilitool.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** 调用用户自己配置的 OpenAI 兼容接口 */
object Ai {
    private fun norm(base: String) = base.trim().trimEnd('/').removeSuffix("/chat/completions").removeSuffix("/models")

    /** 获取模型列表（同时用来测试 地址 + Key 是否可用） */
    suspend fun listModels(base: String, key: String): List<String> = withContext(Dispatchers.IO) {
        val url = norm(base) + "/models"
        if (!url.startsWith("https://")) error("接口地址必须以 https:// 开头")
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 12_000; c.readTimeout = 20_000
            c.setRequestProperty("Authorization", "Bearer $key"); c.setRequestProperty("Accept", "application/json")
            val code = c.responseCode
            val txt = (if (code < 400) c.inputStream else c.errorStream)?.use { String(it.readBytes()) } ?: ""
            if (code >= 400) error("HTTP $code ${txt.take(80)}")
            val j = JSONObject(txt)
            val arr: JSONArray = j.optJSONArray("data") ?: j.optJSONArray("models") ?: error("返回中没有模型列表")
            (0 until arr.length()).mapNotNull {
                val o = arr.opt(it)
                if (o is JSONObject) o.optString("id").ifEmpty { o.optString("name") }.takeIf { s -> s.isNotEmpty() } else (o as? String)
            }.distinct().sorted()
        } finally { c.disconnect() }
    }

    suspend fun chat(conn: AiConn, system: String, user: String): String = withContext(Dispatchers.IO) {
        val url = norm(conn.base) + "/chat/completions"
        if (!url.startsWith("https://")) error("接口地址必须以 https:// 开头")
        val body = JSONObject().put("model", conn.model).put("temperature", 0.3).put(
            "messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", system))
                .put(JSONObject().put("role", "user").put("content", user)),
        )
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "POST"; c.doOutput = true; c.connectTimeout = 15_000; c.readTimeout = 120_000
            c.setRequestProperty("Content-Type", "application/json")
            c.setRequestProperty("Authorization", "Bearer ${conn.key}")
            c.outputStream.use { it.write(body.toString().toByteArray()) }
            val code = c.responseCode
            val txt = (if (code < 400) c.inputStream else c.errorStream)?.use { String(it.readBytes()) } ?: ""
            if (code >= 400) error("AI 接口错误 HTTP $code：${txt.take(200)}")
            JSONObject(txt).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content").trim()
        } finally { c.disconnect() }
    }

    const val COMMENT_SYSTEM = "你是B站评论区分析助手。根据给定的视频信息和评论，用简体中文输出，不要编造评论里没有的内容。格式：\n" +
        "【整体氛围】一两句话\n【主要观点】3-5 条，每条一行\n【争议/分歧】如有\n【有价值的补充信息】如有（如纠错、出处、推荐）"

    fun commentsPrompt(info: VideoInfo, list: List<Comment>): String {
        val sb = StringBuilder("视频标题：${info.title}\nUP主：${info.owner}\n简介：${info.desc.take(300)}\n\n评论（赞数 + 内容）：\n")
        list.filter { it.text.isNotBlank() }.sortedByDescending { it.like }.take(80).forEach { sb.append("[赞${it.like}] ${it.text.replace('\n', ' ').take(140)}\n") }
        return sb.toString()
    }
}
