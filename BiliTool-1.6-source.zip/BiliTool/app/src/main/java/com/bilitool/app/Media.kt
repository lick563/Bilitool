@file:OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.bilitool.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException

@Composable
fun MediaScreen(app: AppState, info: VideoInfo, audio: Boolean, back: () -> Unit) {
    val ctx = LocalContext.current
    var pageIdx by remember { mutableIntStateOf(info.startPage) }
    var opts by remember { mutableStateOf<MediaOpts?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var retry by remember { mutableIntStateOf(0) }
    val sel = remember { mutableStateListOf<Int>() }       // 多选：list 下标
    var fh by remember { mutableStateOf<Int?>(null) }       // 清晰度筛选
    var ff by remember { mutableStateOf<Int?>(null) }       // 帧率筛选

    LaunchedEffect(pageIdx, retry) {
        opts = null; err = null; sel.clear(); fh = null; ff = null
        try {
            val o = Api.options(info.bvid, info.pages[pageIdx].cid)
            opts = o
            if (!audio) {
                val base = if (o.compat != null) 1 else 0
                val d = o.videos.indexOfFirst { it.codecs.startsWith("avc") }.coerceAtLeast(0)
                if (o.videos.isNotEmpty()) sel.add(base + d) else if (o.compat != null) sel.add(0)
            } else if (o.audios.isNotEmpty()) sel.add(0)
        } catch (e: CancellationException) { throw e } catch (e: Exception) { err = e.message ?: "解析失败" }
    }
    val list: List<StreamOpt> = opts?.let { o -> if (audio) o.audios else listOfNotNull(o.compat) + o.videos } ?: emptyList()
    val heights = list.filter { !it.compat && it.height > 0 }.map { it.height }.distinct().sortedDescending()
    val fpss = list.filter { !it.compat && it.fps > 0 }.map { it.fps }.distinct().sortedDescending()
    val visible = list.withIndex().filter { (_, o) -> o.compat || ((fh == null || o.height == fh) && (ff == null || o.fps == ff)) }

    fun codecTag(o: StreamOpt) = if (o.codecs.startsWith("avc")) "AVC" else "HEVC"
    fun doEnqueue() {
        val page = pageIdx + 1
        val key = "${info.bvid}_${info.pages[pageIdx].cid}"
        val base = "${safeName(info.title)}_P$page"
        val bestAudio = opts?.audios?.firstOrNull()
        val specs = sel.sorted().mapNotNull { i -> list.getOrNull(i) }.map { o ->
            when {
                audio -> DlSpec("${base}_${o.bandwidth / 1000}k", o, null, "m4a", "audio/mp4", key)
                o.compat -> DlSpec("${base}_兼容MP4", o, null, "mp4", "video/mp4", key)
                else -> DlSpec("${base}_${o.height}P${o.fps}_${codecTag(o)}", o, bestAudio, "mp4", "video/mp4", key)
            }
        }
        if (specs.isEmpty()) { toast(ctx, "请先选择要下载的项目"); return }
        DownloadCenter.enqueue(ctx, specs)
        toast(ctx, "已加入下载队列（${specs.size} 个），可在通知栏和下载管理查看进度")
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { doEnqueue() }
    fun proceed() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else doEnqueue()
    }
    val storageLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) proceed() else toast(ctx, "需要存储权限才能保存")
    }
    fun start() {
        if (Build.VERSION.SDK_INT < 29 && ContextCompat.checkSelfPermission(ctx, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
            storageLauncher.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE) else proceed()
    }

    PageScaffold(if (audio) "音频提取" else "视频下载", back) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            VideoCard(info)
            if (DownloadCenter.active > 0) Card(onClick = { app.push(Route.Downloads) }, colors = CardDefaults.cardColors(MaterialTheme.colorScheme.tertiaryContainer)) {
                val t = DownloadCenter.tasks.firstOrNull { it.status == DlStatus.Running }
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${DownloadCenter.active} 个任务下载中 · 点击查看", style = MaterialTheme.typography.titleSmall)
                    if (t != null) {
                        Text("${t.spec.fileBase} · ${t.stage} ${if (t.progress >= 0) "${t.pct}%" else ""}", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                        if (t.progress >= 0) LinearWavyProgressIndicator(progress = { t.progress }, Modifier.fillMaxWidth()) else LinearWavyProgressIndicator(Modifier.fillMaxWidth())
                    }
                }
            }
            if (info.pages.size > 1) {
                Text("选择分P", style = MaterialTheme.typography.titleSmall)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(info.pages.size) { i -> FilterChip(pageIdx == i, { pageIdx = i }, { Text("P${i + 1} ${info.pages[i].part}", maxLines = 1) }) }
                }
            }
            if (opts == null && err == null) LoadingBlock("正在获取可用的${if (audio) "音质" else "画质与帧率"}…")
            if (opts != null) {
                if (!audio && (heights.size > 1 || fpss.size > 1)) {
                    Text("筛选", style = MaterialTheme.typography.titleSmall)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(fh == null && ff == null, { fh = null; ff = null }, { Text("全部") })
                        heights.forEach { h -> FilterChip(fh == h, { fh = if (fh == h) null else h }, { Text("${h}P") }) }
                        fpss.forEach { f -> FilterChip(ff == f, { ff = if (ff == f) null else f }, { Text("${f}fps") }) }
                    }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(if (audio) "选择音质（可多选）" else "选择画质 / 帧率 / 编码（可多选）", Modifier.weight(1f), style = MaterialTheme.typography.titleSmall)
                    TextButton({ visible.forEach { if (it.index !in sel) sel.add(it.index) } }) { Text("全选") }
                    TextButton({ sel.clear() }) { Text("清空") }
                }
                if (list.isEmpty()) Text("没有可用选项", color = MaterialTheme.colorScheme.error)
                visible.forEach { (i, o) ->
                    val on = i in sel
                    Card(
                        onClick = { if (on) sel.remove(i) else sel.add(i) },
                        colors = CardDefaults.cardColors(if (on) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceContainer),
                    ) {
                        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(on, { if (it) sel.add(i) else sel.remove(i) })
                            Text(o.label, Modifier.weight(1f).padding(end = 8.dp), style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                Button({ start() }, Modifier.fillMaxWidth(), enabled = sel.isNotEmpty()) {
                    Icon(Icons.Rounded.Download, null); Spacer(Modifier.width(8.dp)); Text("下载所选（${sel.size}）")
                }
                OutlinedButton({ app.push(Route.Downloads) }, Modifier.fillMaxWidth()) { Text("打开下载管理") }
            }
            err?.let { Text(it, color = MaterialTheme.colorScheme.error); if (opts == null) FilledTonalButton({ retry++ }) { Text("重试") } }
            Text(
                if (audio) "音频保存为 M4A（AAC）。MP3 转换需要额外编码库，本版暂未提供。直链需要 B 站 Referer，浏览器直接打开会 403，应用内下载已自动带上。"
                else "未登录时 B 站一般只开放到 480P/720P，可在「设置 → 账号登录」登录后解锁更高画质。下载在后台服务中进行，进度同步显示在通知栏。",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
}

@Composable
fun DownloadsScreen(back: () -> Unit) {
    PageScaffold("下载管理", back, actions = {
        IconButton({ DownloadCenter.clearFinished() }) { Icon(Icons.Rounded.Delete, "清除已完成") }
    }) {
        val tasks = DownloadCenter.tasks
        if (tasks.isEmpty()) Box(Modifier.fillMaxSize(), Alignment.Center) { Text("暂无下载任务", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        else androidx.compose.foundation.lazy.LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            item {
                if (DownloadCenter.active > 0) OutlinedButton({ DownloadCenter.cancelAll() }, Modifier.fillMaxWidth()) { Text("取消全部") }
            }
            items(tasks.reversed(), key = { it.id }) { t ->
                Card(colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(t.spec.fileBase, style = MaterialTheme.typography.titleSmall, maxLines = 2)
                        Text(
                            when (t.status) {
                                DlStatus.Running -> "${t.stage} ${if (t.progress >= 0) "${t.pct}%" else ""}"
                                DlStatus.Failed -> "失败：${t.error ?: ""}"
                                else -> t.stage + (t.error?.let { "（$it）" } ?: "")
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = if (t.status == DlStatus.Failed) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                        if (t.status == DlStatus.Running) {
                            if (t.progress >= 0) LinearWavyProgressIndicator(progress = { t.progress }, Modifier.fillMaxWidth()) else LinearWavyProgressIndicator(Modifier.fillMaxWidth())
                        }
                        if (t.status == DlStatus.Running || t.status == DlStatus.Queued) TextButton({ DownloadCenter.cancel(t) }) { Text("取消") }
                    }
                }
            }
        }
    }
}
