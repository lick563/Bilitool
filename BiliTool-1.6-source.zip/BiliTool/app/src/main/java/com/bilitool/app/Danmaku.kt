@file:OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.bilitool.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 哈希 -> UID 候选、UID -> 昵称 的进程内缓存（跨视频复用） */
object UserCache {
    val uids = mutableStateMapOf<String, List<Long>>()
    val names = mutableStateMapOf<Long, String>()          // 空字符串 = 账号不存在/无法获取

    fun norm(hash: String): String = hash.toLongOrNull(16)?.let { String.format(Locale.US, "%08x", it) } ?: hash.lowercase()

    /** 返回可读的用户描述；尚未解析返回 null */
    fun label(hash: String): String? {
        val c = uids[norm(hash)] ?: return null
        if (c.isEmpty()) return "未找到 UID"
        val named = c.filter { !names[it].isNullOrEmpty() }
        if (named.isNotEmpty()) return named.joinToString(" / ") { "${names[it]}（UID $it）" }
        return c.joinToString(" / ") { "UID $it" }
    }
}

private fun parseTime(s: String): Float? {
    val t = s.trim(); if (t.isEmpty()) return null
    val p = t.split(':', '：').map { it.trim().toFloatOrNull() ?: return null }
    return when (p.size) { 1 -> p[0]; 2 -> p[0] * 60 + p[1]; 3 -> p[0] * 3600 + p[1] * 60 + p[2]; else -> null }
}

private fun modeGroup(m: Int) = when (m) { 1, 2, 3, 6 -> 1; 5 -> 2; 4 -> 3; else -> 4 }

@Composable
fun DanmakuScreen(info: VideoInfo, back: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val df = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }
    var pageIdx by remember { mutableIntStateOf(info.startPage) }
    var list by remember { mutableStateOf<List<Dm>?>(null) }
    var err by remember { mutableStateOf<String?>(null) }
    var loadNote by remember { mutableStateOf("") }
    var segDone by remember { mutableIntStateOf(0) }
    var segTotal by remember { mutableIntStateOf(1) }
    var loaded by remember { mutableIntStateOf(0) }
    var retry by remember { mutableIntStateOf(0) }
    // 筛选 / 排序
    var q by remember { mutableStateOf("") }
    var ts by remember { mutableStateOf("") }
    var te by remember { mutableStateOf("") }
    var modeF by remember { mutableIntStateOf(0) }
    var dateF by remember { mutableIntStateOf(0) }
    var sortM by remember { mutableIntStateOf(0) }
    var showFilter by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var rank by remember { mutableStateOf(false) }
    var sel by remember { mutableStateOf<Dm?>(null) }
    var menu by remember { mutableStateOf(false) }
    var pending by remember { mutableStateOf("") }
    // 用户解析
    var working by remember { mutableStateOf(false) }
    var stage by remember { mutableStateOf("") }
    var prog by remember { mutableFloatStateOf(0f) }
    var msg by remember { mutableStateOf<String?>(null) }
    var job by remember { mutableStateOf<Job?>(null) }

    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        if (uri != null) scope.launch {
            try { withContext(Dispatchers.IO) { writeUri(ctx, uri, pending.toByteArray()) }; toast(ctx, "已导出") }
            catch (e: Exception) { toast(ctx, "导出失败：${e.message}") }
        }
    }

    LaunchedEffect(pageIdx, retry) {
        list = null; err = null; loadNote = ""; segDone = 0; loaded = 0
        try {
            val pg = info.pages[pageIdx]
            val r = Api.danmakuAll(pg.cid, pg.duration) { d, t, c -> segDone = d; segTotal = t; loaded = c }
            list = r.list; loadNote = r.note
            if (r.list.isEmpty() && r.failed > 0) err = r.note.ifEmpty { "未获取到弹幕" }
        } catch (e: CancellationException) { throw e }
        catch (e: Exception) { err = e.message ?: "获取失败" }
    }

    val ver = UserCache.uids.size + UserCache.names.size
    val shown = remember(list, q, ts, te, modeF, dateF, sortM, ver) {
        val l = list ?: return@remember null
        val t0 = parseTime(ts); val t1 = parseTime(te)
        val now = System.currentTimeMillis() / 1000
        val minTs = when (dateF) { 1 -> now - 86400; 2 -> now - 7 * 86400; 3 -> now - 30 * 86400; else -> 0L }
        val key = q.trim()
        val r = l.filter {
            (t0 == null || it.time >= t0) && (t1 == null || it.time <= t1) &&
                (modeF == 0 || modeGroup(it.mode) == modeF) && it.sendTs >= minTs &&
                (key.isEmpty() || it.text.contains(key, true) || it.hash.equals(key, true) || (UserCache.label(it.hash)?.contains(key, true) == true))
        }
        when (sortM) {
            0 -> r.sortedBy { it.time }
            1 -> r.sortedByDescending { it.time }
            2 -> r.sortedByDescending { it.sendTs }
            3 -> r.sortedBy { it.sendTs }
            else -> { val c = r.groupingBy { it.text }.eachCount(); r.sortedWith(compareByDescending<Dm> { c[it.text] ?: 0 }.thenBy { it.time }) }
        }
    }
    val sortNames = listOf("视频时间 ↑", "视频时间 ↓", "发送时间 新→旧", "发送时间 旧→新", "重复次数排行")

    fun resolveUsers() {
        val l = list ?: return
        job?.cancel()
        job = scope.launch {
            working = true; msg = null
            try {
                val freq = l.groupingBy { UserCache.norm(it.hash) }.eachCount()
                val need = freq.keys.filter { it !in UserCache.uids }
                if (need.isNotEmpty()) {
                    stage = "第 1/2 步：反查用户 ID（${need.size} 个不同用户，约 10~40 秒）"; prog = 0f
                    val r = Crc.reverseAll(need) { prog = it }
                    need.forEach { UserCache.uids[it] = r[it] ?: emptyList() }
                }
                val uidList = freq.entries.sortedByDescending { it.value }
                    .flatMap { UserCache.uids[it.key] ?: emptyList() }.distinct().filter { it !in UserCache.names }.take(1000)
                stage = "第 2/2 步：查询用户名（${uidList.size} 个账号）"; prog = 0f
                val chunks = uidList.chunked(50)
                chunks.forEachIndexed { i, c ->
                    val m = Api.userNames(c)
                    c.forEach { UserCache.names[it] = m[it] ?: "" }
                    prog = (i + 1f) / chunks.size; delay(200)
                }
                val total = freq.size; val ok = freq.keys.count { k -> UserCache.uids[k]?.any { !UserCache.names[it].isNullOrEmpty() } == true }
                msg = "完成：$total 位用户中 $ok 位已识别昵称"
            } catch (e: CancellationException) { throw e }
            catch (e: Exception) { msg = "中断：${e.message}（已识别的结果已保留，可稍后重试）" }
            finally { working = false }
        }
    }

    fun export(kind: String) {
        val l = shown ?: return
        val base = "${safeName(info.title)}_P${pageIdx + 1}"
        when (kind) {
            "csv" -> {
                val sb = StringBuilder("\uFEFF时间(秒),时间,模式,颜色,发送时间,用户哈希,用户,内容\n")
                l.forEach {
                    val color = String.format(Locale.US, "#%06X", it.color and 0xFFFFFF)
                    val user = (UserCache.label(it.hash) ?: "").replace("\"", "\"\"")
                    sb.append("${it.time},${fmtTime(it.time)},${modeName(it.mode)},$color,${df.format(Date(it.sendTs * 1000))},${it.hash},\"$user\",\"${it.text.replace("\"", "\"\"")}\"\n")
                }
                pending = sb.toString()
            }
            "json" -> {
                val a = JSONArray()
                l.forEach { a.put(JSONObject().put("time", it.time.toDouble()).put("mode", it.mode).put("color", it.color and 0xFFFFFF).put("sendTime", it.sendTs).put("hash", it.hash).put("user", UserCache.label(it.hash) ?: JSONObject.NULL).put("text", it.text)) }
                pending = a.toString(2)
            }
            else -> pending = l.joinToString("\n") { "[${fmtTime(it.time)}] ${UserCache.label(it.hash)?.let { u -> "$u：" } ?: ""}${it.text}" }
        }
        saver.launch("$base.$kind")
    }

    PageScaffold("弹幕查询", { job?.cancel(); back() }, actions = {
        IconButton({ menu = true }, enabled = !shown.isNullOrEmpty()) { Icon(Icons.Rounded.Save, "导出（当前筛选结果）") }
        DropdownMenu(menu, { menu = false }) {
            listOf("csv" to "导出 CSV（可用 Excel 打开）", "json" to "导出 JSON", "txt" to "导出 TXT").forEach { (k, n) ->
                DropdownMenuItem({ Text(n) }, { menu = false; export(k) })
            }
        }
    }) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
            item { Text(info.title, Modifier.padding(horizontal = 16.dp), style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis) }
            if (info.pages.size > 1) item {
                LazyRow(contentPadding = PaddingValues(16.dp, 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(info.pages.size) { i ->
                        FilterChip(pageIdx == i, { if (!working) pageIdx = i }, { Text("P${i + 1} ${info.pages[i].part}", maxLines = 1) })
                    }
                }
            }
            item {
                OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(16.dp, 8.dp), singleLine = true, shape = MaterialTheme.shapes.extraLarge,
                    label = { Text("搜索内容 / 用户名 / UID / 哈希") }, leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    trailingIcon = { if (q.isNotEmpty()) IconButton({ q = "" }) { Icon(Icons.Rounded.Close, "清空") } },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search), keyboardActions = KeyboardActions())
            }
            if (list == null && err == null) item {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    LoadingBlock("正在加载全部弹幕：已读 $segDone/$segTotal 段，已获取 $loaded 条", onCancel = back)
                    LinearWavyProgressIndicator(progress = { if (segTotal > 0) segDone.toFloat() / segTotal else 0f }, Modifier.fillMaxWidth())
                }
            }
            err?.let { e ->
                item {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(e, color = MaterialTheme.colorScheme.error)
                        FilledTonalButton({ retry++ }) { Text("重试") }
                    }
                }
            }
            val l = shown
            if (list != null) {
                item {
                    Card(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), colors = CardDefaults.cardColors(MaterialTheme.colorScheme.secondaryContainer)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("共获取 ${list!!.size} 条弹幕（含全部分段，已去重）", style = MaterialTheme.typography.titleSmall)
                            if (loadNote.isNotEmpty()) {
                                Text(loadNote, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                                FilledTonalButton({ retry++ }) { Text("重新加载") }
                            }
                            Text("弹幕里记录的是用户哈希，不是用户名。点击下方按钮可批量反查 UID 并查询昵称。", style = MaterialTheme.typography.bodySmall)
                            if (working) {
                                Text(stage, style = MaterialTheme.typography.bodyMedium)
                                LinearWavyProgressIndicator(progress = { prog }, Modifier.fillMaxWidth())
                                TextButton({ job?.cancel(); working = false }) { Text("取消") }
                            } else Button({ resolveUsers() }) { Icon(Icons.Rounded.Person, null); Spacer(Modifier.width(8.dp)); Text("解析用户名") }
                            msg?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
                        }
                    }
                }
                item {
                    Row(Modifier.padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(showFilter, { showFilter = !showFilter }, { Text("筛选") }, leadingIcon = { Icon(Icons.Rounded.FilterList, null, Modifier.size(18.dp)) })
                        Box {
                            AssistChip({ sortMenu = true }, { Text(sortNames[sortM]) })
                            DropdownMenu(sortMenu, { sortMenu = false }) {
                                sortNames.forEachIndexed { i, n -> DropdownMenuItem({ Text(n) }, { sortM = i; sortMenu = false }) }
                            }
                        }
                        AssistChip({ rank = true }, { Text("排行榜") }, leadingIcon = { Icon(Icons.Rounded.EmojiEvents, null, Modifier.size(18.dp)) })
                    }
                }
                if (showFilter) item {
                    Column(Modifier.padding(16.dp, 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("按视频时间段（mm:ss 或秒数）", style = MaterialTheme.typography.labelLarge)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedTextField(ts, { ts = it }, Modifier.weight(1f), singleLine = true, label = { Text("从") }, placeholder = { Text("00:00") })
                            OutlinedTextField(te, { te = it }, Modifier.weight(1f), singleLine = true, label = { Text("到") }, placeholder = { Text(fmtTime(info.pages[pageIdx].duration.toFloat())) })
                        }
                        Text("弹幕类型", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("全部", "滚动", "顶部", "底部", "其他").forEachIndexed { i, n -> FilterChip(modeF == i, { modeF = i }, { Text(n) }) }
                        }
                        Text("发送时间", style = MaterialTheme.typography.labelLarge)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("全部", "今天内", "7 天内", "30 天内").forEachIndexed { i, n -> FilterChip(dateF == i, { dateF = i }, { Text(n) }) }
                        }
                        TextButton({ ts = ""; te = ""; modeF = 0; dateF = 0; q = "" }) { Text("重置筛选") }
                    }
                }
                item {
                    Text("筛选后 ${l?.size ?: 0} 条", Modifier.padding(horizontal = 16.dp, vertical = 4.dp), style = MaterialTheme.typography.labelLarge)
                }
                items(l ?: emptyList()) { d ->
                    ListItem(
                        modifier = Modifier.clickable { sel = d },
                        overlineContent = { Text("${fmtTime(d.time)} · ${modeName(d.mode)}") },
                        headlineContent = { Text(d.text, maxLines = 3, overflow = TextOverflow.Ellipsis) },
                        supportingContent = { Text("${UserCache.label(d.hash) ?: "哈希 ${d.hash}"} · ${df.format(Date(d.sendTs * 1000))}", maxLines = 2) },
                    )
                }
            }
        }
    }
    sel?.let { DmDialog(it, df) { sel = null } }
    if (rank) RankDialog(list ?: emptyList(), onPick = { q = it; rank = false }) { rank = false }
}

@Composable
private fun RankDialog(all: List<Dm>, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val topText = remember(all) { all.groupingBy { it.text }.eachCount().entries.sortedByDescending { it.value }.take(50) }
    val topUser = remember(all) { all.groupingBy { UserCache.norm(it.hash) }.eachCount().entries.sortedByDescending { it.value }.take(50) }
    AlertDialog(
        onDismissRequest = onDismiss, title = { Text("弹幕排行榜") },
        text = {
            Column {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(tab == 0, { tab = 0 }, { Text("高频弹幕") }); FilterChip(tab == 1, { tab = 1 }, { Text("活跃用户") })
                }
                LazyColumn(Modifier.heightIn(max = 420.dp)) {
                    if (tab == 0) items(topText.size) { i ->
                        val e = topText[i]
                        ListItem(Modifier.clickable { onPick(e.key) }, leadingContent = { Text("${i + 1}") },
                            headlineContent = { Text(e.key, maxLines = 2) }, trailingContent = { Text("${e.value} 次") })
                    } else items(topUser.size) { i ->
                        val e = topUser[i]
                        ListItem(Modifier.clickable { onPick(e.key) }, leadingContent = { Text("${i + 1}") },
                            headlineContent = { Text(UserCache.label(e.key) ?: "哈希 ${e.key}", maxLines = 2) }, trailingContent = { Text("${e.value} 条") })
                    }
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("关闭") } },
    )
}

@Composable
private fun DmDialog(dm: Dm, df: SimpleDateFormat, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val cands = UserCache.uids[UserCache.norm(dm.hash)]
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("弹幕详情") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(dm.text, style = MaterialTheme.typography.bodyLarge)
                Text("出现于 ${fmtTime(dm.time)} · ${modeName(dm.mode)} · " + String.format(Locale.US, "#%06X", dm.color and 0xFFFFFF), style = MaterialTheme.typography.bodySmall)
                Text("发送于 ${df.format(Date(dm.sendTs * 1000))}", style = MaterialTheme.typography.bodySmall)
                Text("用户哈希 ${dm.hash}", style = MaterialTheme.typography.bodySmall)
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                if (cands == null) Text("尚未解析用户，请返回列表点击“解析用户名”。", style = MaterialTheme.typography.bodyMedium)
                else if (cands.isEmpty()) Text("在 1~45 亿范围内未找到对应 UID。", style = MaterialTheme.typography.bodyMedium)
                else cands.forEach { uid ->
                    val n = UserCache.names[uid]
                    ListItem(
                        modifier = Modifier.clickable { openUrl(ctx, "https://space.bilibili.com/$uid") },
                        headlineContent = { Text(if (n.isNullOrEmpty()) "UID $uid" else n) },
                        supportingContent = { Text(if (n.isNullOrEmpty()) "未获取到昵称（账号可能不存在，属于哈希碰撞）" else "UID $uid · 点击打开主页") },
                    )
                }
            }
        },
        confirmButton = { TextButton(onDismiss) { Text("关闭") } },
        dismissButton = { TextButton({ copyText(ctx, dm.text) }) { Text("复制内容") } },
    )
}
