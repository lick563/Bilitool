@file:OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class)

package com.bilitool.app

import android.content.ClipboardManager
import android.os.Build
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp

const val VERSION_NAME = "1.6"
const val VERSION_CODE = 7

// ===================== 首页 =====================
@Composable
fun HomeScreen(app: AppState) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val focus = LocalFocusManager.current
    PageScaffold("BiliTool", null, insets = false) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 16.dp + LocalBottomBarPadding.current), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                // Emphasized：整屏仅此一处强调样式
                Text("粘贴链接，一键解析", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold)
                Text("弹幕查询 · 封面提取 · 视频下载 · 音频提取", style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            item {
                OutlinedTextField(
                    value = app.input, onValueChange = { app.input = it }, modifier = Modifier.fillMaxWidth(),
                    label = { Text("视频链接 / BV号 / av号 / b23.tv 短链") }, maxLines = 3,
                    shape = MaterialTheme.shapes.large,
                    trailingIcon = {
                        if (app.input.isNotEmpty()) IconButton({ app.input = "" }) { Icon(Icons.Rounded.Close, "清空") }
                        else IconButton({
                            val t = ctx.getSystemService(ClipboardManager::class.java).primaryClip?.getItemAt(0)?.text
                            if (t != null) app.input = t.toString() else toast(ctx, "剪贴板为空")
                        }) { Icon(Icons.Rounded.ContentPaste, "粘贴") }
                    },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
                    keyboardActions = KeyboardActions(onGo = { focus.clearFocus(); if (app.input.isNotBlank()) app.query(scope) }),
                )
            }
            item {
                // Shape morph：按下时圆角由胶囊变为圆角矩形（spatial spring）
                val src = remember { MutableInteractionSource() }
                val pressed by src.collectIsPressedAsState()
                val corner by animateDpAsState(if (pressed) 14.dp else 28.dp, spatialSpec(Speed.Fast), label = "morph")
                Button(
                    onClick = { focus.clearFocus(); app.query(scope) }, interactionSource = src,
                    shape = RoundedCornerShape(corner.coerceAtLeast(0.dp)),
                    enabled = app.input.isNotBlank() && !app.loading,
                    modifier = Modifier.fillMaxWidth().height(56.dp),
                ) { Icon(Icons.Rounded.Search, null); Spacer(Modifier.width(8.dp)); Text("一键解析") }
            }
            if (app.loading) item { LoadingBlock("正在解析视频信息…", onCancel = { app.cancelQuery() }) }
            if (DownloadCenter.active > 0) item {
                val t = DownloadCenter.tasks.firstOrNull { it.status == DlStatus.Running }
                Card(onClick = { app.push(Route.Downloads) }, colors = CardDefaults.cardColors(MaterialTheme.colorScheme.tertiaryContainer)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("${DownloadCenter.active} 个下载任务进行中 · 点击查看", style = MaterialTheme.typography.titleSmall)
                        if (t != null) {
                            Text("${t.spec.fileBase} · ${t.stage} ${if (t.progress >= 0) "${t.pct}%" else ""}", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                            if (t.progress >= 0) LinearWavyProgressIndicator(progress = { t.progress }, Modifier.fillMaxWidth()) else LinearWavyProgressIndicator(Modifier.fillMaxWidth())
                        }
                    }
                }
            }
            app.error?.let { e ->
                item {
                    Card(colors = CardDefaults.cardColors(MaterialTheme.colorScheme.errorContainer)) {
                        Text(e, Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onErrorContainer)
                    }
                }
            }
            val info = app.info
            if (info != null && !app.loading) {
                item { VideoCard(info) }
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton({ app.push(Route.Danmaku(info)) }, Modifier.weight(1f)) { Icon(Icons.Rounded.ChatBubble, null); Spacer(Modifier.width(6.dp)); Text("弹幕查询") }
                            FilledTonalButton({ app.push(Route.Cover(info)) }, Modifier.weight(1f)) { Icon(Icons.Rounded.Image, null); Spacer(Modifier.width(6.dp)); Text("提取封面") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton({ app.push(Route.Media(info, false)) }, Modifier.weight(1f)) { Icon(Icons.Rounded.Videocam, null); Spacer(Modifier.width(6.dp)); Text("下载视频") }
                            FilledTonalButton({ app.push(Route.Media(info, true)) }, Modifier.weight(1f)) { Icon(Icons.Rounded.MusicNote, null); Spacer(Modifier.width(6.dp)); Text("提取音频") }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            FilledTonalButton({ app.push(Route.Comments(info)) }, Modifier.weight(1f)) { Icon(Icons.Rounded.Forum, null); Spacer(Modifier.width(6.dp)); Text("读评论") }
                            FilledTonalButton({ app.push(Route.Summary(info)) }, Modifier.weight(1f)) { Icon(Icons.Rounded.AutoAwesome, null); Spacer(Modifier.width(6.dp)); Text("AI总结") }
                        }
                    }
                }
            } else if (!app.loading && app.error == null) {
                item {
                    Card(colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainer)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("使用方法", style = MaterialTheme.typography.titleMedium)
                            Text("1. 在 B 站复制视频链接或 BV 号\n2. 粘贴到上方并点击“一键解析”\n3. 选择需要的工具，无需登录",
                                style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun VideoCard(info: VideoInfo) {
    Card(shape = MaterialTheme.shapes.extraLarge, colors = CardDefaults.cardColors(MaterialTheme.colorScheme.surfaceContainerLow)) {
        RemoteImage(info.cover, Modifier.fillMaxWidth().aspectRatio(16f / 9f))
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(info.title, style = MaterialTheme.typography.titleMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text("UP：${info.owner} · ${info.bvid} · ${info.pages.size}P", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text("播放 ${info.view.fmtCount()}  弹幕 ${info.danmaku.fmtCount()}  点赞 ${info.like.fmtCount()}  投币 ${info.coin.fmtCount()}  收藏 ${info.favorite.fmtCount()}",
                style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
        }
    }
}

// ===================== 工具 =====================
private data class Tool(val name: String, val desc: String, val icon: ImageVector, val go: () -> Unit)

@Composable
fun ToolsScreen(app: AppState) {
    val ctx = LocalContext.current
    val tools = listOf(
        Tool("弹幕查询", "查看/搜索/导出弹幕", Icons.Rounded.ChatBubble) { app.withInfo(ctx) { app.push(Route.Danmaku(it)) } },
        Tool("封面提取", "保存视频封面原图", Icons.Rounded.Image) { app.withInfo(ctx) { app.push(Route.Cover(it)) } },
        Tool("视频下载", "获取并下载 MP4", Icons.Rounded.Videocam) { app.withInfo(ctx) { app.push(Route.Media(it, false)) } },
        Tool("音频提取", "提取 M4A 音轨", Icons.Rounded.MusicNote) { app.withInfo(ctx) { app.push(Route.Media(it, true)) } },
        Tool("读评论", "热评/最新评论，AI 总结观点", Icons.Rounded.Forum) { app.withInfo(ctx) { app.push(Route.Comments(it)) } },
        Tool("AI总结", "视频内容 AI 总结", Icons.Rounded.AutoAwesome) { app.withInfo(ctx) { app.push(Route.Summary(it)) } },
        Tool("下载管理", "后台下载与进度", Icons.Rounded.Download) { app.push(Route.Downloads) },
        Tool("账号登录", "登录获取 Cookie", Icons.Rounded.Person) { app.push(Route.Login) },
        Tool("AI设置", "多板块 · 测试 · 选模型", Icons.Rounded.SmartToy) { app.push(Route.AiSettings) },
        Tool("热词百科", "弹幕梗 / 热词解释", Icons.Rounded.MenuBook) { app.push(Route.Buzzwords) },
        Tool("B站热搜", "实时热搜榜", Icons.Rounded.LocalFireDepartment) { app.push(Route.Hot) },
        Tool("短链还原", "b23.tv 还原为完整链接", Icons.Rounded.Link) { app.push(Route.ShortLink) },
        Tool("历史记录", "最近解析的视频", Icons.Rounded.History) { app.tab = 2 },
        Tool("关于", "作者与开源致谢", Icons.Rounded.Info) { app.push(Route.About) },
    )
    PageScaffold("更多工具", null, insets = false) {
        LazyVerticalGrid(
            GridCells.Adaptive(160.dp), Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 16.dp + LocalBottomBarPadding.current),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            gridItems(tools) { t ->
                Card(onClick = t.go, shape = MaterialTheme.shapes.extraLarge,
                    colors = CardDefaults.cardColors(MaterialTheme.colorScheme.secondaryContainer)) {
                    Column(Modifier.padding(16.dp).heightIn(min = 110.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primary) {
                            Icon(t.icon, null, Modifier.padding(10.dp).size(24.dp), tint = MaterialTheme.colorScheme.onPrimary)
                        }
                        Text(t.name, style = MaterialTheme.typography.titleMedium)
                        Text(t.desc, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    }
                }
            }
        }
    }
}

// ===================== 历史 =====================
@Composable
fun HistoryScreen(app: AppState) {
    val scope = rememberCoroutineScope()
    val df = remember { java.text.SimpleDateFormat("MM-dd HH:mm", java.util.Locale.getDefault()) }
    PageScaffold("历史记录", null, insets = false, actions = {
        if (app.history.isNotEmpty()) IconButton({ app.clearHistory() }) { Icon(Icons.Rounded.Delete, "清空历史") }
    }) {
        if (app.history.isEmpty()) {
            Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.History, null, Modifier.size(48.dp), tint = MaterialTheme.colorScheme.outline)
                    Text("还没有解析记录", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(top = 8.dp, bottom = 8.dp + LocalBottomBarPadding.current)) {
            items(app.history, key = { it.bvid }) { h ->
                ListItem(
                    modifier = Modifier.clickable { app.input = h.bvid; app.tab = 0; app.query(scope, h.bvid) },
                    leadingContent = { RemoteImage(h.cover, Modifier.width(96.dp).aspectRatio(16f / 9f).clip8()) },
                    headlineContent = { Text(h.title, maxLines = 2, overflow = TextOverflow.Ellipsis) },
                    supportingContent = { Text("${h.owner} · ${df.format(java.util.Date(h.ts))}") },
                    trailingContent = { IconButton({ app.removeHistory(h) }) { Icon(Icons.Rounded.Close, "删除") } },
                )
            }
        }
    }
}

private fun Modifier.clip8(): Modifier = this.clip(RoundedCornerShape(8.dp))

// ===================== 设置 =====================
@Composable
fun SettingsScreen(app: AppState) {
    val reduce = LocalReduceMotion.current
    val modes = listOf("跟随系统", "浅色", "深色")
    val ok = Build.VERSION.SDK_INT >= 31
    PageScaffold("设置", null, insets = false) {
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(bottom = 16.dp + LocalBottomBarPadding.current)) {
            SettingsGroup("外观", listOf(
                {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("主题", style = MaterialTheme.typography.bodyLarge)
                        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                            modes.forEachIndexed { i, l ->
                                SegmentedButton(app.themeMode == i, { app.setTheme(i) }, SegmentedButtonDefaults.itemShape(i, modes.size)) { Text(l) }
                            }
                        }
                    }
                },
                {
                    SettingRow("动态取色", if (ok) "跟随壁纸生成配色（Material You）" else "Android 12 以下使用内置 B站粉 配色", Icons.Rounded.Palette,
                        trailing = { Switch(app.dynamic && ok, { app.setDynamicColor(it) }, enabled = ok) })
                },
                {
                    SettingRow("动画", if (reduce) "系统已开启“移除动画”，弹簧已降级为短淡入淡出" else "Material 3 Expressive 弹簧动效，跟随系统“移除动画”降级", Icons.Rounded.Animation)
                },
            ))
            SettingsGroup("账号与服务", listOf(
                {
                    SettingRow("账号登录", if (app.cookie.contains("SESSDATA=")) "已登录：${app.userName ?: "验证中…"}" else "未登录 · 登录后可解锁高画质",
                        Icons.Rounded.Person, trailing = { Chevron() }, onClick = { app.push(Route.Login) })
                },
                {
                    SettingRow("AI 设置", app.aiConn()?.let { "使用中：${it.label}" } ?: "未选择模型 · 添加板块并选择模型",
                        Icons.Rounded.AutoAwesome, trailing = { Chevron() }, onClick = { app.push(Route.AiSettings) })
                },
                {
                    SettingRow("下载管理", if (DownloadCenter.active > 0) "${DownloadCenter.active} 个任务进行中" else "查看下载进度与记录",
                        Icons.Rounded.Download, trailing = { Chevron() }, onClick = { app.push(Route.Downloads) })
                },
            ))
            SettingsGroup("帮助", listOf(
                { SettingRow("重新查看新手引导", null, Icons.Rounded.Help, trailing = { Chevron() }, onClick = { app.replayGuide() }) },
                { SettingRow("关于 BiliTool", "版本 $VERSION_NAME · 作者与开源致谢", Icons.Rounded.Info, trailing = { Chevron() }, onClick = { app.push(Route.About) }) },
            ))
        }
    }
}

// ===================== 关于 =====================
@Composable
fun AboutScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    val credits = listOf(
        Triple("Jetpack Compose Material 3（Expressive）", "Google · AndroidX", "https://developer.android.com/jetpack/androidx/releases/compose-material3"),
        Triple("Material Components for Android", "material-components/material-components-android", "https://github.com/material-components/material-components-android"),
        Triple("Material Symbols / Icons", "google/material-design-icons", "https://github.com/google/material-design-icons"),
        Triple("Kotlin Coroutines", "Kotlin/kotlinx.coroutines", "https://github.com/Kotlin/kotlinx.coroutines"),
        Triple("bilibili-API-collect", "SocialSisterYi/bilibili-API-collect（接口参考）", "https://github.com/SocialSisterYi/bilibili-API-collect"),
        Triple("Bibz", "bibz.me（功能灵感与热词数据）", "https://bibz.me/"),
    )
    PageScaffold("关于", back) {
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 16.dp + LocalBottomBarPadding.current), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            item {
                Card(shape = MaterialTheme.shapes.extraLarge, colors = CardDefaults.cardColors(MaterialTheme.colorScheme.primaryContainer)) {
                    Column(Modifier.padding(24.dp).fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("BiliTool", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
                        Text("B站工具箱 · 版本 $VERSION_NAME", color = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                }
            }
            item {
                Text("作者", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                ListItem(headlineContent = { Text("Claude") }, supportingContent = { Text("由 Anthropic 的 AI 助手 Claude 编写") },
                    leadingContent = { Icon(Icons.Rounded.AutoAwesome, null) })
                ListItem(headlineContent = { Text("B站主页") }, supportingContent = { Text("https://b23.tv/LEyDyuc") },
                    leadingContent = { Icon(Icons.Rounded.OpenInBrowser, null) },
                    modifier = Modifier.clickable { openUrl(ctx, "https://b23.tv/LEyDyuc") })
                ListItem(headlineContent = { Text("QQ：1549179079") }, supportingContent = { Text("点击复制") },
                    leadingContent = { Icon(Icons.Rounded.ContentCopy, null) },
                    modifier = Modifier.clickable { copyText(ctx, "1549179079") })
            }
            item { Text("感谢致谢", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary) }
            items(credits) { (name, repo, url) ->
                ListItem(headlineContent = { Text(name) }, supportingContent = { Text("$repo\n$url") },
                    modifier = Modifier.clickable { openUrl(ctx, url) })
            }
            item {
                Text("更新日志", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                Text("1.6  评论长按复制/选择复制；@用户可点击查询；图片全屏缩放保存；用户资料含头像/头图保存与全部信息复制。\n1.5  新手引导与更新提示；评论头像/图片/用户查询/图标/分页；AI 与设置改为 M3 分组设置样式（右上角添加）；热词展开与翻页。\n1.4  账号登录获取 Cookie；弹幕全量分段加载+时间段/类型/发送时间筛选+排行榜；评论加载全部与全部回复；热词百科离线词典，点击直达B站搜索；下载改为后台服务（通知栏进度/多选/下载管理）；AI 多板块设置、一键测试、选择模型。\n1.3  新增读评论（热门/最新、置顶、IP属地）与 AI 总结（B站官方视频总结 + 自定义 AI 总结评论）；下载加入 WBI 签名与备用线路以修复 403。\n1.2  底部导航栏改为液态玻璃（Liquid Glass），支持拖动切换。\n1.1  修复音频下载 403；视频支持选择画质/帧率/编码并自动合并音轨；弹幕可批量反查 UID 并显示用户名。\n1.0  首个版本：弹幕查询/导出、封面提取、视频下载、音频提取、热词百科、热搜、短链还原、历史记录；Material 3 Expressive 动效、动态取色、预测性返回。",
                    style = MaterialTheme.typography.bodyMedium)
            }
            item {
                Text("本应用仅供学习交流，请尊重 UP 主版权，下载内容不得用于商业用途。", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
