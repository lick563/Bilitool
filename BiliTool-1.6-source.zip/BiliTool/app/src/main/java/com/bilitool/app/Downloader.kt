package com.bilitool.app

import android.content.ContentValues
import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaMuxer
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import kotlinx.coroutines.*
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer

/** 自己带 Referer/UA 下载（B站 CDN 没有 Referer 会 403），并依次尝试备用线路 */
object Downloader {
    private val MIRRORS = listOf("upos-sz-mirrorali.bilivideo.com", "upos-sz-mirrorcos.bilivideo.com", "upos-sz-mirrorhw.bilivideo.com")

    /** 原始线路 + 备用线路 + 官方镜像节点（部分 PCDN/mcdn 线路对非浏览器会 403） */
    private fun candidates(urls: List<String>): List<String> {
        val out = LinkedHashSet<String>(urls)
        urls.forEach { u ->
            val uri = java.net.URI(u)
            if (uri.path?.startsWith("/upgcxcode/") == true) MIRRORS.forEach { m ->
                out.add("https://$m${uri.rawPath}${uri.rawQuery?.let { "?$it" } ?: ""}")
            }
        }
        return out.toList()
    }

    suspend fun fetch(urls: List<String>, out: File, onProgress: (Long, Long) -> Unit) = withContext(Dispatchers.IO) {
        val errors = ArrayList<String>()
        for (u in candidates(urls)) {
            for (range in listOf(true, false)) {
                try { one(u, out, range, onProgress); return@withContext }
                catch (e: CancellationException) { throw e }
                catch (e: Exception) {
                    errors.add("${java.net.URI(u).host}: ${e.message}")
                    if (e.message?.contains("403") != true) break      // 非 403 无需换请求头重试
                }
            }
        }
        error("所有线路均失败（${errors.size} 次）\n" + errors.take(4).joinToString("\n"))
    }

    private suspend fun one(url: String, out: File, withRange: Boolean, onProgress: (Long, Long) -> Unit) {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15_000; c.readTimeout = 30_000
        c.setRequestProperty("User-Agent", Api.UA)
        c.setRequestProperty("Referer", "https://www.bilibili.com/")
        c.setRequestProperty("Origin", "https://www.bilibili.com")
        c.setRequestProperty("Accept", "*/*")
        c.setRequestProperty("Accept-Encoding", "identity")
        if (withRange) c.setRequestProperty("Range", "bytes=0-")
        try {
            val code = c.responseCode
            if (code != 200 && code != 206) error("HTTP $code")
            val total = c.getHeaderField("Content-Range")?.substringAfter('/')?.toLongOrNull() ?: c.contentLengthLong
            var done = 0L
            c.inputStream.use { ins ->
                out.outputStream().use { os ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val n = ins.read(buf); if (n < 0) break
                        os.write(buf, 0, n); done += n
                        onProgress(done, total)
                    }
                }
            }
        } finally { c.disconnect() }
    }

    /** 用系统 MediaMuxer 把 DASH 的视频流与音频流合并为 MP4（支持 AVC / HEVC + AAC） */
    fun mux(video: File, audio: File, out: File) {
        val ve = MediaExtractor().apply { setDataSource(video.path) }
        val ae = MediaExtractor().apply { setDataSource(audio.path) }
        val muxer = MediaMuxer(out.path, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        try {
            val vt = track(ve, "video/"); val at = track(ae, "audio/")
            ve.selectTrack(vt); ae.selectTrack(at)
            val vi = muxer.addTrack(ve.getTrackFormat(vt)); val ai = muxer.addTrack(ae.getTrackFormat(at))
            muxer.start()
            copy(ve, muxer, vi); copy(ae, muxer, ai)
            muxer.stop()
        } finally { runCatching { muxer.release() }; ve.release(); ae.release() }
    }

    private fun track(e: MediaExtractor, prefix: String): Int {
        for (i in 0 until e.trackCount) if (e.getTrackFormat(i).getString("mime")?.startsWith(prefix) == true) return i
        error("流中没有 $prefix 轨道")
    }

    private fun copy(e: MediaExtractor, m: MediaMuxer, track: Int) {
        val buf = ByteBuffer.allocateDirect(4 * 1024 * 1024)
        val info = MediaCodec.BufferInfo()
        while (true) {
            val n = e.readSampleData(buf, 0); if (n < 0) break
            info.set(0, n, e.sampleTime, if (e.sampleFlags and MediaExtractor.SAMPLE_FLAG_SYNC != 0) MediaCodec.BUFFER_FLAG_KEY_FRAME else 0)
            m.writeSampleData(track, buf, info)
            e.advance()
        }
    }

    /** 保存到 Download/BiliTool（Android 10+ 走 MediaStore，无需权限） */
    fun save(ctx: Context, src: File, name: String, mime: String) {
        if (Build.VERSION.SDK_INT >= 29) {
            val r = ctx.contentResolver
            val v = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name); put(MediaStore.Downloads.MIME_TYPE, mime)
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/BiliTool"); put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: error("无法创建文件")
            r.openOutputStream(uri)!!.use { os -> src.inputStream().use { it.copyTo(os) } }
            v.clear(); v.put(MediaStore.Downloads.IS_PENDING, 0); r.update(uri, v, null, null)
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "BiliTool").apply { mkdirs() }
            src.copyTo(File(dir, name), overwrite = true)
        }
    }
}
