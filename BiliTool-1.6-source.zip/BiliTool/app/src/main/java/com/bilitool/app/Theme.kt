@file:OptIn(ExperimentalMaterial3ExpressiveApi::class)

package com.bilitool.app

import android.app.Activity
import android.os.Build
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.tween
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

/** 系统“移除动画”开启时，弹簧降级为短时长淡入淡出，而不是取消反馈 */
val LocalReduceMotion = staticCompositionLocalOf { false }

enum class Speed { Fast, Default, Slow }

/** Spatial：位置/尺寸/形状，允许轻微过冲 */
@Composable
fun <T> spatialSpec(speed: Speed = Speed.Default): FiniteAnimationSpec<T> {
    if (LocalReduceMotion.current) return tween(90)
    val m = MaterialTheme.motionScheme
    return when (speed) { Speed.Fast -> m.fastSpatialSpec(); Speed.Default -> m.defaultSpatialSpec(); Speed.Slow -> m.slowSpatialSpec() }
}

/** Effects：颜色/透明度，平顺无回弹 */
@Composable
fun <T> effectsSpec(speed: Speed = Speed.Default): FiniteAnimationSpec<T> {
    if (LocalReduceMotion.current) return tween(90)
    val m = MaterialTheme.motionScheme
    return when (speed) { Speed.Fast -> m.fastEffectsSpec(); Speed.Default -> m.defaultEffectsSpec(); Speed.Slow -> m.slowEffectsSpec() }
}

// Android 12 以下的静态品牌色（B站粉，已按 WCAG AA 取色）
private val LightScheme = lightColorScheme(
    primary = Color(0xFFB41F5A), onPrimary = Color.White,
    primaryContainer = Color(0xFFFFD9E2), onPrimaryContainer = Color(0xFF3E001D),
    secondary = Color(0xFF74565F), onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFD9E2), onSecondaryContainer = Color(0xFF2B151C),
    tertiary = Color(0xFF7C5635), onTertiary = Color.White,
    tertiaryContainer = Color(0xFFFFDCC2), onTertiaryContainer = Color(0xFF2E1500),
    background = Color(0xFFFFF8F8), onBackground = Color(0xFF201A1B),
    surface = Color(0xFFFFF8F8), onSurface = Color(0xFF201A1B),
    surfaceVariant = Color(0xFFF3DDE1), onSurfaceVariant = Color(0xFF514346),
    surfaceContainerLowest = Color.White, surfaceContainerLow = Color(0xFFFFF0F2),
    surfaceContainer = Color(0xFFFCEAED), surfaceContainerHigh = Color(0xFFF6E4E7),
    surfaceContainerHighest = Color(0xFFF0DEE1),
    outline = Color(0xFF857376), outlineVariant = Color(0xFFD6C2C5),
    error = Color(0xFFBA1A1A), onError = Color.White,
)
private val DarkScheme = darkColorScheme(
    primary = Color(0xFFFFB1C8), onPrimary = Color(0xFF650033),
    primaryContainer = Color(0xFF8E0F45), onPrimaryContainer = Color(0xFFFFD9E2),
    secondary = Color(0xFFE3BDC6), onSecondary = Color(0xFF422932),
    secondaryContainer = Color(0xFF5A3F47), onSecondaryContainer = Color(0xFFFFD9E2),
    tertiary = Color(0xFFEFBD94), onTertiary = Color(0xFF48290C),
    tertiaryContainer = Color(0xFF623F20), onTertiaryContainer = Color(0xFFFFDCC2),
    background = Color(0xFF181113), onBackground = Color(0xFFECDFE0),
    surface = Color(0xFF181113), onSurface = Color(0xFFECDFE0),
    surfaceVariant = Color(0xFF514346), onSurfaceVariant = Color(0xFFD6C2C5),
    surfaceContainerLowest = Color(0xFF130C0E), surfaceContainerLow = Color(0xFF201A1B),
    surfaceContainer = Color(0xFF241E1F), surfaceContainerHigh = Color(0xFF2F282A),
    surfaceContainerHighest = Color(0xFF3A3335),
    outline = Color(0xFF9F8C90), outlineVariant = Color(0xFF514346),
    error = Color(0xFFFFB4AB), onError = Color(0xFF690005),
)

@Composable
fun BiliToolTheme(dynamic: Boolean, themeMode: Int, content: @Composable () -> Unit) {
    val dark = when (themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val ctx = LocalContext.current
    val scheme = when {
        dynamic && Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> DarkScheme
        else -> LightScheme
    }
    val view = LocalView.current
    SideEffect {
        (view.context as? Activity)?.window?.let { w ->
            WindowCompat.getInsetsController(w, view).apply {
                isAppearanceLightStatusBars = !dark; isAppearanceLightNavigationBars = !dark
            }
        }
    }
    MaterialExpressiveTheme(colorScheme = scheme, motionScheme = MotionScheme.expressive(), content = content)
}
