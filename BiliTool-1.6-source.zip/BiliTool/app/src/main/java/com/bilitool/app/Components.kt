@file:OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class)

package com.bilitool.app

import android.content.*
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.LruCache
import android.widget.Toast
import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.BrokenImage
import androidx.compose.material.icons.rounded.Person
import androidx.compose.ui.draw.clip
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch

fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

fun copyText(ctx: Context, text: String) {
    ctx.getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("BiliTool", text))
    toast(ctx, "已复制")
}

fun openUrl(ctx: Context, url: String) {
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (_: Exception) { toast(ctx, "无法打开链接") }
}

/** 直接跳转到 B 站（App 优先，没装则用网页搜索）搜索关键词 */
fun openBiliSearch(ctx: Context, kw: String) {
    val e = java.net.URLEncoder.encode(kw, "UTF-8")
    try { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("bilibili://search?keyword=$e")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    catch (_: Exception) { openUrl(ctx, "https://search.bilibili.com/all?keyword=$e") }
}

fun shareText(ctx: Context, text: String) {
    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
    ctx.startActivity(Intent.createChooser(i, "分享").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

fun writeUri(ctx: Context, uri: Uri, data: ByteArray) {
    ctx.contentResolver.openOutputStream(uri)?.use { it.write(data) } ?: error("无法写入文件")
}

fun safeName(s: String) = s.replace(Regex("""[\\/:*?"<>|\s]+"""), "_").take(60)

/** 标题大号折叠的页面骨架；content 限宽 720dp 以适配平板/折叠屏 */
@Composable
fun PageScaffold(
    title: String, onBack: (() -> Unit)?, insets: Boolean = true,
    actions: @Composable RowScope.() -> Unit = {}, content: @Composable () -> Unit,
) {
    val sb = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    Scaffold(
        modifier = Modifier.nestedScroll(sb.nestedScrollConnection),
        contentWindowInsets = if (insets) ScaffoldDefaults.contentWindowInsets else WindowInsets(0, 0, 0, 0),
        topBar = {
            LargeTopAppBar(
                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                navigationIcon = {
                    if (onBack != null) IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "返回") }
                },
                actions = actions, scrollBehavior = sb,
            )
        },
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            Box(Modifier.widthIn(max = 720.dp).fillMaxSize()) { content() }
        }
    }
}

/** Skeleton 闪烁：1400ms，FastOutSlowIn，往返 */
@Composable
fun Modifier.shimmer(): Modifier {
    val reduce = LocalReduceMotion.current
    val base = MaterialTheme.colorScheme.surfaceContainerHighest
    val hi = MaterialTheme.colorScheme.surfaceContainerLow
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(0f, 1f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "x")
    return drawBehind {
        val w = size.width
        val start = if (reduce) 0f else -w + x * 2 * w
        drawRect(Brush.horizontalGradient(listOf(base, hi, base), startX = start, endX = start + w))
    }
}

/** 不确定加载（5 秒内）：Expressive LoadingIndicator + 语义化文案 + 取消入口 */
@Composable
fun LoadingBlock(text: String, modifier: Modifier = Modifier, onCancel: (() -> Unit)? = null) {
    Column(
        modifier.fillMaxWidth().padding(24.dp).semantics { liveRegion = LiveRegionMode.Polite },
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        LoadingIndicator()
        Text(text, style = MaterialTheme.typography.bodyMedium)
        if (onCancel != null) TextButton(onClick = onCancel) { Text("取消") }
    }
}

object Img {
    private val cache = object : LruCache<String, Bitmap>(24 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    suspend fun load(url: String, maxW: Int = 1080): Bitmap {
        cache.get(url)?.let { return it }
        return withContext(Dispatchers.IO) {
            val b = Api.bytes(url)
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(b, 0, b.size, o)
            var s = 1
            while (o.outWidth / (s * 2) >= maxW) s *= 2
            val bm = BitmapFactory.decodeByteArray(b, 0, b.size, BitmapFactory.Options().apply { inSampleSize = s })
                ?: error("图片解码失败")
            cache.put(url, bm); bm
        }
    }
}

@Composable
fun RemoteImage(url: String, modifier: Modifier = Modifier, contentScale: ContentScale = ContentScale.Crop, maxW: Int = 1080) {
    var bmp by remember(url) { mutableStateOf<Bitmap?>(null) }
    var failed by remember(url) { mutableStateOf(false) }
    LaunchedEffect(url) {
        try { bmp = Img.load(url, maxW) } catch (e: kotlinx.coroutines.CancellationException) { throw e } catch (_: Exception) { failed = true }
    }
    val alpha by animateFloatAsState(if (bmp != null) 1f else 0f, effectsSpec(), label = "imgAlpha")
    Box(modifier, contentAlignment = Alignment.Center) {
        val b = bmp
        when {
            b != null -> Image(b.asImageBitmap(), null, Modifier.matchParentSize().graphicsLayer { this.alpha = alpha }, contentScale = contentScale)
            failed -> Icon(Icons.Rounded.BrokenImage, "加载失败", tint = MaterialTheme.colorScheme.outline)
            else -> Box(Modifier.matchParentSize().shimmer())
        }
    }
}

@Composable
fun Avatar(url: String, size: androidx.compose.ui.unit.Dp, modifier: Modifier = Modifier) {
    Box(modifier.size(size).clip(androidx.compose.foundation.shape.CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHighest), contentAlignment = Alignment.Center) {
        if (url.isBlank()) Icon(Icons.Rounded.Person, null, tint = MaterialTheme.colorScheme.outline)
        else RemoteImage(url, Modifier.fillMaxSize(), maxW = 160)
    }
}

/** 选择保存位置并保存一张网络图片（SAF，无需存储权限） */
@Composable
fun rememberImageSaver(): (String) -> Unit {
    val ctx = LocalContext.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var pending by remember { mutableStateOf("") }
    val launcher = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.CreateDocument("image/*")) { uri ->
        if (uri != null) scope.launch {
            try { val b = Api.bytes(pending); withContext(Dispatchers.IO) { writeUri(ctx, uri, b) }; toast(ctx, "图片已保存") }
            catch (e: Exception) { toast(ctx, "保存失败：${e.message}") }
        }
    }
    return { url ->
        pending = url
        val ext = url.substringAfterLast('.').substringBefore('?').takeIf { it.length in 3..4 } ?: "jpg"
        launcher.launch("bilitool_${System.currentTimeMillis()}.$ext")
    }
}
