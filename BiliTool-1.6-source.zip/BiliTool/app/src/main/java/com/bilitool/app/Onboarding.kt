@file:OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class)

package com.bilitool.app

import androidx.compose.animation.core.animateDpAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch

private data class GuidePage(val icon: ImageVector, val title: String, val body: String)

private val GUIDE = listOf(
    GuidePage(Icons.Rounded.Home, "欢迎使用 BiliTool", "一个纯本地的 B 站工具箱：解析视频、查弹幕、读评论、提取封面、下载视频与音频。"),
    GuidePage(Icons.Rounded.ContentPaste, "粘贴链接即可解析", "在首页粘贴视频链接、BV 号、av 号或 b23.tv 短链，点击“一键解析”，下面就会出现所有可用工具。"),
    GuidePage(Icons.Rounded.ChatBubble, "弹幕、评论与下载", "弹幕会读取全部分段并支持筛选、排行和导出；评论可翻页、看图、查用户；下载在后台进行，通知栏显示进度。"),
    GuidePage(Icons.Rounded.AutoAwesome, "登录与 AI（可选）", "在“设置”里登录账号可解锁更高画质；添加 AI 板块并选好模型后，可一键总结评论与视频内容。"),
)

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val state = rememberPagerState { GUIDE.size }
    val scope = rememberCoroutineScope()
    val spec = spatialSpec<Float>()
    val last = state.currentPage == GUIDE.size - 1
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.surface) {
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                if (!last) TextButton(onDone) { Text("跳过") } else Spacer(Modifier.height(48.dp))
            }
            HorizontalPager(state, Modifier.weight(1f)) { i ->
                val g = GUIDE[i]
                Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Surface(shape = androidx.compose.foundation.shape.RoundedCornerShape(40.dp), color = MaterialTheme.colorScheme.primaryContainer) {
                        Icon(g.icon, null, Modifier.padding(36.dp).size(72.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                    }
                    Spacer(Modifier.height(32.dp))
                    Text(g.title, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.ExtraBold, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(12.dp))
                    Text(g.body, style = MaterialTheme.typography.bodyLarge, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Row(Modifier.padding(vertical = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                GUIDE.indices.forEach { i ->
                    val w by animateDpAsState(if (state.currentPage == i) 28.dp else 8.dp, spatialSpec(Speed.Fast), label = "dot")
                    Box(Modifier.height(8.dp).width(w.coerceAtLeast(8.dp)).clip(CircleShape)
                        .background(if (state.currentPage == i) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant))
                }
            }
            Button(
                { if (last) onDone() else scope.launch { state.animateScrollToPage(state.currentPage + 1, animationSpec = spec) } },
                Modifier.fillMaxWidth().height(56.dp),
            ) { Text(if (last) "开始使用" else "下一步") }
        }
    }
}

val RELEASE_NOTES = listOf(
    "评论长按：复制内容 / 选择文字复制 / 复制用户名与 UID",
    "评论里的 @用户 可直接点击查询",
    "图片全屏查看，支持双指缩放、双击放大、左右翻页与保存",
    "用户资料：可放大并保存头像、头图，复制全部详细信息",
)

@Composable
fun UpdateDialog(onKnow: () -> Unit, onSnooze: () -> Unit) {
    AlertDialog(
        onDismissRequest = onSnooze,
        icon = { Icon(Icons.Rounded.Info, null) },
        title = { Text("已更新到 $VERSION_NAME") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("本次更新：", style = MaterialTheme.typography.labelLarge)
                RELEASE_NOTES.forEach { Text("• $it", style = MaterialTheme.typography.bodyMedium) }
            }
        },
        confirmButton = { TextButton(onKnow) { Text("知道了") } },
        dismissButton = { TextButton(onSnooze) { Text("今日不再弹出") } },
    )
}
