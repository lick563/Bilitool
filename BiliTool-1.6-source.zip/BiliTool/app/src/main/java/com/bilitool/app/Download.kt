package com.bilitool.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.io.File

/** main = 视频流（或单文件/音频流）；audio 不为空时下载后与 main 合并 */
data class DlSpec(val fileBase: String, val main: StreamOpt, val audio: StreamOpt?, val ext: String, val mime: String, val cacheKey: String)

enum class DlStatus { Queued, Running, Done, Failed, Canceled }

class DlTask(val id: Int, val spec: DlSpec) {
    var status by mutableStateOf(DlStatus.Queued)
    var stage by mutableStateOf("等待中")
    var progress by mutableFloatStateOf(0f)     // <0 表示不确定
    var error by mutableStateOf<String?>(null)
    var job: Job? = null
    val pct get() = if (progress < 0) 0 else (progress * 100).toInt().coerceIn(0, 100)
}

object DownloadCenter {
    val tasks = mutableStateListOf<DlTask>()
    private var seq = 0
    val active get() = tasks.count { it.status == DlStatus.Queued || it.status == DlStatus.Running }

    fun enqueue(ctx: Context, specs: List<DlSpec>) {
        specs.forEach { tasks.add(DlTask(++seq, it)) }
        ContextCompat.startForegroundService(ctx, Intent(ctx, DownloadService::class.java))
    }

    fun cancel(t: DlTask) {
        if (t.status == DlStatus.Queued) { t.status = DlStatus.Canceled; t.stage = "已取消" } else t.job?.cancel()
    }

    fun cancelAll() { tasks.toList().forEach { if (it.status == DlStatus.Queued || it.status == DlStatus.Running) cancel(it) } }
    fun clearFinished() { tasks.removeAll { it.status == DlStatus.Done || it.status == DlStatus.Failed || it.status == DlStatus.Canceled } }
}

object DownloadWorker {
    private fun cacheDir(ctx: Context) = File(ctx.cacheDir, "dl").apply { mkdirs() }
    fun cleanCache(ctx: Context) { cacheDir(ctx).deleteRecursively() }

    suspend fun run(ctx: Context, t: DlTask) {
        val s = t.spec
        val tmp = File(cacheDir(ctx), "t${t.id}").apply { deleteRecursively(); mkdirs() }
        try {
            if (s.audio == null) {
                t.stage = "下载中"; t.progress = 0f
                val f = File(tmp, "single")
                Downloader.fetch(s.main.urls, f) { d, total -> t.progress = if (total > 0) d.toFloat() / total else -1f }
                t.stage = "保存中"; t.progress = -1f
                withContext(Dispatchers.IO) { Downloader.save(ctx, f, "${s.fileBase}.${s.ext}", s.mime) }
                return
            }
            val v = File(tmp, "v.m4s")
            t.stage = "下载视频流"
            Downloader.fetch(s.main.urls, v) { d, total -> t.progress = if (total > 0) 0.9f * 0.55f * d / total else -1f }
            val a = File(cacheDir(ctx), "aud_${s.cacheKey}.m4s")
            val ok = File(cacheDir(ctx), "aud_${s.cacheKey}.ok")
            if (!(a.exists() && ok.exists())) {
                t.stage = "下载音频流"
                Downloader.fetch(s.audio.urls, a) { d, total -> t.progress = if (total > 0) 0.495f + 0.9f * 0.35f * d / total else -1f }
                ok.writeText("1")
            }
            t.stage = "合并音视频"; t.progress = 0.92f
            val out = File(tmp, "out.mp4")
            val merged = withContext(Dispatchers.IO) { try { Downloader.mux(v, a, out); true } catch (_: Exception) { false } }
            t.stage = "保存中"; t.progress = 0.97f
            withContext(Dispatchers.IO) {
                if (merged) Downloader.save(ctx, out, "${s.fileBase}.mp4", "video/mp4")
                else {
                    Downloader.save(ctx, v, "${s.fileBase}_视频流.mp4", "video/mp4")
                    Downloader.save(ctx, a, "${s.fileBase}_音频流.m4a", "audio/mp4")
                }
            }
            if (!merged) t.error = "此设备无法合并，已分别保存视频流和音频流"
        } finally { tmp.deleteRecursively() }
    }
}

class DownloadService : Service() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(CH, "下载", NotificationManager.IMPORTANCE_LOW))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) { DownloadCenter.cancelAll(); return START_NOT_STICKY }
        val n = buildNotif(null)
        if (Build.VERSION.SDK_INT >= 29) startForeground(FG_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC) else startForeground(FG_ID, n)
        if (loop?.isActive != true) loop = scope.launch { runQueue() }
        return START_NOT_STICKY
    }

    private suspend fun runQueue() {
        val nm = getSystemService(NotificationManager::class.java)
        while (true) {
            val t = DownloadCenter.tasks.firstOrNull { it.status == DlStatus.Queued } ?: break
            t.status = DlStatus.Running
            val j = scope.launch {
                try {
                    DownloadWorker.run(applicationContext, t)
                    t.progress = 1f; t.stage = "已保存到 Download/BiliTool"; t.status = DlStatus.Done
                    doneNotif(t, true)
                } catch (e: CancellationException) { t.status = DlStatus.Canceled; t.stage = "已取消"; throw e }
                catch (e: Exception) { t.status = DlStatus.Failed; t.stage = "失败"; t.error = e.message; doneNotif(t, false) }
            }
            t.job = j
            val ticker = scope.launch { while (isActive) { nm.notify(FG_ID, buildNotif(t)); delay(500) } }
            j.join(); ticker.cancel()
        }
        DownloadWorker.cleanCache(applicationContext)
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun buildNotif(t: DlTask?): Notification {
        val left = DownloadCenter.active
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val cancel = PendingIntent.getService(this, 1, Intent(this, DownloadService::class.java).setAction(ACTION_CANCEL), PendingIntent.FLAG_IMMUTABLE)
        val b = NotificationCompat.Builder(this, CH)
            .setSmallIcon(android.R.drawable.stat_sys_download).setOngoing(true).setOnlyAlertOnce(true)
            .setContentIntent(open).addAction(0, "取消全部", cancel)
            .setContentTitle("BiliTool 下载中（剩余 $left 个）")
        if (t == null) b.setContentText("准备中…").setProgress(0, 0, true)
        else b.setContentText("${t.spec.fileBase} · ${t.stage} ${if (t.progress >= 0) "${t.pct}%" else ""}")
            .setProgress(100, t.pct, t.progress < 0)
        return b.build()
    }

    private fun doneNotif(t: DlTask, ok: Boolean) {
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, CH)
            .setSmallIcon(if (ok) android.R.drawable.stat_sys_download_done else android.R.drawable.stat_notify_error)
            .setContentTitle(if (ok) "下载完成" else "下载失败")
            .setContentText(t.spec.fileBase + (t.error?.let { " · ${it.take(60)}" } ?: ""))
            .setAutoCancel(true).setContentIntent(open).build()
        getSystemService(NotificationManager::class.java).notify(1000 + t.id, n)
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    companion object { const val CH = "download"; const val FG_ID = 42; const val ACTION_CANCEL = "com.bilitool.app.CANCEL_ALL" }
}
