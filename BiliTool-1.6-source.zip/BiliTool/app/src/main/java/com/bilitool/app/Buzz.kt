@file:OptIn(ExperimentalMaterial3ExpressiveApi::class, ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)

package com.bilitool.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp

data class BuzzEntry(val word: String, val cat: String, val intro: String)

private fun b(w: String, c: String, i: String) = BuzzEntry(w, c, i)

/** 离线热词词典：全部写在代码里，无需联网；每个词条都有介绍 */
val BUZZ_LIST: List<BuzzEntry> = listOf(
    // ---- 弹幕文化 ----
    b("前方高能", "弹幕文化", "弹幕提醒：接下来有精彩、爆笑或惊吓的画面，请做好准备。也常被反用来调侃“其实没什么”。"),
    b("高能预警", "弹幕文化", "与“前方高能”同义，提醒观众后面的画面刺激、搞笑或需要心理准备。"),
    b("空降", "弹幕文化", "拖动进度条直接跳到视频某个时间点。弹幕里常发“空降 xx:xx”，告诉大家那里有精彩片段。"),
    b("空降成功", "弹幕文化", "观众按弹幕提示跳到指定时间点后，刷一句表示“我到了”。"),
    b("弹幕护体", "弹幕文化", "恐怖或惊吓画面出现时，观众刷满屏弹幕来壮胆、遮挡画面。"),
    b("课代表", "弹幕文化", "在弹幕或评论里替大家总结视频要点、整理笔记的人，像课堂上收作业的课代表一样热心。"),
    b("一键三连", "弹幕文化", "同时点赞、投币、收藏，是对 UP 主最有力的支持，也是 B 站最经典的互动用语。"),
    b("三连", "弹幕文化", "“一键三连”的简称，指点赞 + 投币 + 收藏。"),
    b("下次一定", "弹幕文化", "观众被催三连时的调侃回应：嘴上答应、迟迟不兑现。后来泛指敷衍、推脱。"),
    b("白嫖", "弹幕文化", "只看内容、不点赞投币收藏，泛指不付出成本就获得好处。UP 主常自嘲“被白嫖”。"),
    b("恰饭", "弹幕文化", "“吃饭”的戏称，指 UP 主接商业推广赚钱。观众说“UP 要恰饭”表示理解。"),
    b("充电", "弹幕文化", "B 站的打赏方式，用电池给 UP 主赞助，“为 UP 充电”即支持创作者。"),
    b("前排", "弹幕文化", "在评论区或弹幕里抢占靠前的位置，表示“我来得早”。"),
    b("沙发", "弹幕文化", "指评论区第一条评论的位置，抢到的人会说“沙发”。后续还有“板凳”“地板”。"),
    b("打卡", "弹幕文化", "在评论或弹幕里留下“到此一游”的记录，如“xx 年打卡”，常见于老视频和经典作品。"),
    b("名场面", "弹幕文化", "作品里令人印象深刻、被反复提起和二次创作的经典片段。"),
    b("二创", "弹幕文化", "对原作品的二次创作，如混剪、配音、翻唱、改编、手书等。"),
    b("鬼畜", "弹幕文化", "B 站标志性内容形式：把素材剪辑成高频重复、节奏洗脑的视频，也有独立的鬼畜区。"),
    b("洗脑", "弹幕文化", "旋律或台词太上头，让人不由自主地反复想起、哼唱。"),
    b("生肉", "弹幕文化", "没有字幕或翻译的外语原版视频，看不懂只能“啃生肉”。"),
    b("熟肉", "弹幕文化", "已经加好字幕或完成翻译的视频，与“生肉”相对。"),
    b("整活", "弹幕文化", "做出搞怪、有创意的节目效果或行为，让观众觉得有趣。"),
    b("电子榨菜", "弹幕文化", "吃饭时随手看的轻松下饭视频，不用动脑，像榨菜一样配饭。"),
    b("避雷", "弹幕文化", "提醒别人避开不好的内容、商品或地点。"),
    b("安利", "弹幕文化", "热情地向别人推荐自己喜欢的作品、产品，希望对方也喜欢。"),
    b("吹爆", "弹幕文化", "极力称赞，常和“安利”连用：把喜欢的东西夸到极致。"),
    b("种草", "弹幕文化", "被推荐后产生想买、想看、想尝试的冲动。"),
    b("拔草", "弹幕文化", "已经买到或尝试了心心念念的东西，愿望达成；也可指看完评价后决定不买。"),
    b("打 call", "弹幕文化", "原指为偶像应援挥舞荧光棒，现泛指给喜欢的人或事加油助威。"),
    b("催更", "弹幕文化", "催促 UP 主或作者尽快更新作品。"),
    b("咕咕咕", "弹幕文化", "拟声“鸽子叫”，借“鸽子”谐音指 UP 主或作者拖更、失约，也说“鸽了”。"),
    b("本命", "弹幕文化", "最喜欢的角色、偶像或作品，是“最爱”的意思。"),
    b("DD", "弹幕文化", "“到处喜欢”的缩写，指同时喜欢很多偶像（尤其是虚拟主播）的人。"),
    b("泪目", "弹幕文化", "被剧情或内容感动到眼眶湿润，是弹幕里最常见的感动表达。"),
    b("神回复", "弹幕文化", "评论区里机智、搞笑又点睛的回复，常获得大量点赞。"),
    b("剧透", "弹幕文化", "提前透露剧情关键内容。弹幕里常有人提醒“前方剧透”或“劝你别看弹幕”。"),
    b("二次元", "弹幕文化", "指动画、漫画、游戏等虚拟世界及其爱好者圈子，与现实的“三次元”相对。"),
    b("萌新", "弹幕文化", "刚加入某个圈子或游戏的新手，带点可爱的自称或称呼。"),
    b("大佬", "弹幕文化", "在某个领域特别厉害的人，是对高手的尊称。"),
    b("肝", "弹幕文化", "熬夜或投入大量时间精力，“肝帝”指拼命投入的人，“爆肝”则是极致投入。"),
    b("氪金", "弹幕文化", "在游戏等产品里花钱充值，常与“肝”形成对比：肝靠时间，氪靠钱。"),
    b("欧皇", "弹幕文化", "抽卡、抽奖运气极好的人，与之相对的是运气差的“非酋”。"),
    b("非酋", "弹幕文化", "抽卡、抽奖运气极差的人，常自嘲“非到离谱”。"),
    // ---- 网络缩写 ----
    b("awsl", "网络缩写", "“啊我死了”的拼音缩写，表达被萌到、被感动到、被帅到的夸张反应。"),
    b("yyds", "网络缩写", "“永远的神”的拼音缩写，用来表达对某人或某事物的极致称赞。"),
    b("爷青回", "网络缩写", "“爷的青春回来了”，看到经典作品、老歌或老朋友重现时的感慨。"),
    b("爷青结", "网络缩写", "“爷的青春结束了”，喜爱的作品完结或重要人物离开时的感叹。"),
    b("xswl", "网络缩写", "“笑死我了”的拼音缩写，形容觉得特别好笑。"),
    b("u1s1", "网络缩写", "“有一说一”的缩写，表示就事论事、说句公道话。"),
    b("nsdd", "网络缩写", "“你说得对”的拼音缩写，常带有无奈或敷衍的语气。"),
    b("233", "网络缩写", "表示大笑的数字梗，来自早期论坛的笑倒表情编号，2333 越长越好笑。"),
    b("666", "网络缩写", "“溜溜溜”的谐音，表示厉害、佩服；也可简写成一个“6”。"),
    b("草", "网络缩写", "表示好笑或无语，来自日语网络用语里用“w”表示笑的习惯（“草”的由来），有时也作感叹词。"),
    b("栓 Q", "网络缩写", "“thank you”的谐音，带着无奈或反讽语气的“谢谢”。"),
    // ---- 情绪表达 ----
    b("破防", "情绪表达", "心理防线被击穿，被感动、被扎心或被气到，情绪一下子绷不住。"),
    b("破大防", "情绪表达", "“破防”的加强版，形容情绪彻底崩溃或感动到不行。"),
    b("蚌埠住了", "情绪表达", "“绷不住了”的谐音梗，指忍不住笑出来或情绪撑不住。"),
    b("绝绝子", "情绪表达", "表示极度夸赞或极度吐槽，褒贬由语境决定，是一种强调情绪的叠字说法。"),
    b("好家伙", "情绪表达", "表示惊讶、感叹，常在看到出乎意料的情况时发出。"),
    b("离谱", "情绪表达", "形容事情荒唐、出乎常理，让人难以置信；“离大谱”是更强的说法。"),
    b("芜湖", "情绪表达", "表示兴奋、起飞的感叹词，常说“芜湖起飞”。"),
    b("针不戳", "情绪表达", "“真不错”的谐音梗，用来表示称赞，带点俏皮。"),
    b("笑死", "情绪表达", "形容觉得非常好笑，常作为弹幕里的最高频反应之一。"),
    b("我太难了", "情绪表达", "自嘲处境艰难、压力大，常带着幽默的无奈。"),
    b("小丑竟是我自己", "情绪表达", "发现被嘲笑或看不起的对象其实是自己，表示自嘲式的醒悟。"),
    b("社死", "情绪表达", "“社会性死亡”的缩写，指在公众场合出丑、尴尬到想消失。"),
    b("无语", "情绪表达", "遇到离谱的事情不知道说什么好，是一种吐槽性的反应。"),
    b("绷不住", "情绪表达", "忍不住笑出声或情绪失控，不再维持镇定。"),
    // ---- 社会生活 ----
    b("内卷", "社会生活", "指同行或同群体过度竞争、投入越来越多却回报递减的现象，也用来形容“大家都在拼命”。"),
    b("躺平", "社会生活", "对高强度竞争不再追逐，选择低欲望、低消耗的生活方式。"),
    b("摆烂", "社会生活", "情况不理想时索性不再努力，任其发展，带点自嘲与放弃。"),
    b("打工人", "社会生活", "上班族的自嘲式称呼，常配“打工人，打工魂”之类的励志式吐槽。"),
    b("上岸", "社会生活", "通过考试、考研、考公或求职成功，从备考的焦虑状态脱离出来。"),
    b("润", "社会生活", "“run”的音译，网络上指离开、跑路，也有“溜了”的玩笑意味。"),
    b("懂的都懂", "社会生活", "不明说，默认有共同经历或认知的人心知肚明，带点神秘或玩笑的意味。"),
    b("凡尔赛", "社会生活", "以低调抱怨的方式炫耀自己的优越生活，来自“凡尔赛文学”。"),
    b("柠檬精", "社会生活", "形容羡慕嫉妒的人，因为“酸”，自嘲时常说“我酸了”。"),
    b("阴阳怪气", "社会生活", "说话拐弯抹角、带讽刺，表面礼貌实则刻薄。"),
    b("神仙打架", "社会生活", "形容高手之间的对决或精彩的互动，旁观者看得过瘾。"),
    b("有内味了", "社会生活", "“有那个味道了”，形容复刻或还原得很到位，找回了熟悉的感觉。"),
    b("真香", "社会生活", "先放狠话说不会做，结果立刻改口并且觉得很爽的打脸式反转，源自网络视频里的名场面。"),
    b("啊对对对", "社会生活", "敷衍式回应，表示“你说得都对，我懒得争”，常带讽刺语气。"),
    b("抽象", "社会生活", "原指艺术概念，网络上形容行为或言论荒诞、难以理解、反常规的梗文化。"),
    b("典", "社会生活", "“典型”的缩写，常说“典中典”，形容某事极具代表性，常带调侃。"),
    b("泰裤辣", "社会生活", "“太酷啦”的带口音谐音，形容非常酷、非常棒，来自网络玩梗。"),
    b("尊嘟假嘟", "社会生活", "“真的假的”的卖萌式说法，表示惊讶和质疑。"),
    b("退退退", "社会生活", "表示让对方走开、拒绝围观或表示被冒犯的网络用语，也有玩梗的成分。"),
    b("皮一下", "社会生活", "忍不住调皮、开个小玩笑，常说“皮一下很开心”。"),
    b("肥肠", "社会生活", "“非常”的谐音，用可爱的语气强调程度，如“肥肠好看”。"),
    b("一个能打的都没有", "社会生活", "形容在场的人都不够强，常用来吐槽实力太弱，或者夸张地表示“都不行”。"),
)

val BUZZ_CATS: List<String> = listOf("全部") + BUZZ_LIST.map { it.cat }.distinct()

private const val BUZZ_PAGE = 10

@Composable
fun BuzzScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("全部") }
    var page by remember { mutableIntStateOf(0) }
    var open by remember { mutableStateOf<String?>(null) }      // 当前展开的词
    val listState = androidx.compose.foundation.lazy.rememberLazyListState()
    val filtered = remember(q, cat) {
        BUZZ_LIST.filter { (cat == "全部" || it.cat == cat) && (q.isBlank() || it.word.contains(q.trim(), true) || it.intro.contains(q.trim(), true)) }
    }
    val pages = maxOf(1, (filtered.size + BUZZ_PAGE - 1) / BUZZ_PAGE)
    if (page >= pages) page = pages - 1
    val shown = filtered.drop(page * BUZZ_PAGE).take(BUZZ_PAGE)
    LaunchedEffect(q, cat) { page = 0; open = null }
    LaunchedEffect(page) { listState.scrollToItem(0) }

    PageScaffold("热词百科", back) {
        LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = 24.dp)) {
            item {
                OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth().padding(16.dp, 8.dp), singleLine = true, shape = MaterialTheme.shapes.extraLarge,
                    label = { Text("搜索热词或解释（共 ${BUZZ_LIST.size} 条）") }, leadingIcon = { Icon(Icons.Rounded.Search, null) },
                    trailingIcon = { if (q.isNotEmpty()) IconButton({ q = "" }) { Icon(Icons.Rounded.Close, "清空") } })
            }
            item {
                FlowRow(Modifier.padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BUZZ_CATS.forEach { c -> FilterChip(cat == c, { cat = c }, { Text(c) }) }
                }
            }
            item {
                Text("筛选出 ${filtered.size} 条 · 第 ${page + 1}/$pages 页", Modifier.padding(16.dp, 8.dp), style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (shown.isEmpty()) item { Text("没有匹配的热词", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant) }
            item {
                if (shown.isNotEmpty()) SettingsGroup(null, shown.map<BuzzEntry, @Composable () -> Unit> { e ->
                    {
                        val expanded = open == e.word
                        Column(Modifier.fillMaxWidth().clickable { open = if (expanded) null else e.word }.padding(horizontal = 16.dp, vertical = 12.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(e.word, Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
                                Text(e.cat, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                Icon(if (expanded) Icons.Rounded.ExpandLess else Icons.Rounded.ExpandMore, if (expanded) "收起" else "展开")
                            }
                            Text(e.intro, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = if (expanded) Int.MAX_VALUE else 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            if (expanded) TextButton({ openBiliSearch(ctx, e.word) }) {
                                Icon(Icons.Rounded.Search, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("在 B 站搜索")
                            }
                        }
                    }
                })
            }
            item {
                Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                    OutlinedButton({ page--; open = null }, enabled = page > 0) { Icon(Icons.Rounded.ChevronLeft, null); Text("上一页") }
                    Text("${page + 1} / $pages", style = MaterialTheme.typography.labelLarge)
                    Button({ page++; open = null }, enabled = page < pages - 1) { Text("下一页"); Icon(Icons.Rounded.ChevronRight, null) }
                }
            }
        }
    }
}
